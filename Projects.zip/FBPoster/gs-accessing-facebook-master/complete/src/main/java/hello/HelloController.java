package hello;

import facebook4j.*;
import facebook4j.api.PostMethods;
import facebook4j.auth.AccessToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import sun.security.provider.MD5;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/")
public class HelloController {

    List<FBPost> posts = new ArrayList<>(3);

    class FBPost {
        String msg;
        URL url;
        URL img;
        String desc;
    }

    void setPosts()  throws MalformedURLException  {

        FBPost p1 = new FBPost();
        p1.msg = "\uD83D\uDE00\uD83D\uDE03\uD83D\uDE04\uD83D\uDE01\uD83D\uDE06\uD83D\uDE05\uD83D\uDE02\uD83E\uDD23 გთავაზობთ, ქალაქ ზუგდიდის ინტელექტ-ჩემპიონატის ყველაზე მაღალქულიანი მოსწავლეების რეიტინგს";
        p1.img = new URL("http://www.etaloni.ge/gallery/iiiiiiireitingi.jpg");
        p1.url = new URL("http://www.etaloni.ge/geo/main/index/4371");
        p1.desc = "გთავაზობთ, ქალაქ ზუგდიდის ინტელექტ-ჩემპიონატის ყველაზე მაღალქულიანი მოსწავლეების რეიტინგს";


        FBPost p2 = new FBPost();
        p2.msg = "\uD83E\uDD27\uD83E\uDD25\uD83D\uDE13\uD83C\uDF83\uD83C\uDF83\uD83D\uDC7E ''ეტალონის'' ახმეტის მუნიციპალიტეტის მონაწილეთა სია ცნობილია";
        p2.img = new URL("http://www.etaloni.ge/gallery/iaxmeta.jpg");
        p2.url = new URL("http://www.etaloni.ge/geo/main/index/4382");
        p2.desc = "ახმეტის N2 სკოლაში ინტელექტ-შეჯიბრი ''ეტალონი'' ჩატარდება. ინტელექტუალური კონკურსი 18 ოქტომბერს, 15:00-ზე დაიწყება.";

        this.posts.add(p1);
        this.posts.add(p2);
    }

    @GetMapping
    public String helloFacebook(Model model) throws Exception {
            facebook4j.Facebook facebook = new FacebookFactory().getInstance();

            facebook.setOAuthAppId("610383785664169", "97585e158d2db0a6c04e624931e8e7c0");
            facebook.setOAuthPermissions("ads_management,ads_read,business_management,email,instagram_basic,instagram_manage_comments,instagram_manage_insights,manage_pages,pages_manage_cta,pages_manage_instant_articles,pages_messaging,pages_messaging_subscriptions,pages_messaging_payments,pages_messaging_phone_number,pages_show_list,publish_actions,publish_pages,public_profile,read_audience_network_insights,read_custom_friendlists,read_insights,read_page_mailboxes,rsvp_event,user_about_me,user_actions.books,user_actions.fitness,user_actions.music,user_actions.news,user_actions.video,user_birthday,user_education_history,user_events,user_friends,user_games_activity,user_hometown,user_likes,user_location,user_managed_groups,user_photos,user_posts,user_relationship_details,user_relationships,user_religion_politics,user_tagged_places,user_videos,user_website,user_work_history");
            facebook.setOAuthAccessToken(new AccessToken("EAACEdEose0cBAD1NXLjCTXOf8DchseZB4lObEQd77nGF9BqitFkaQSr0tZAZBcX5pdPuK85M7p8hOpNEbZCZBcxbAQXdyLYORNUyv0I2sAa8TsVYeb3ho5mW3x6yggkyEsIKVTZBf4IxC0LhRGLf9LuNJv4v7ZBYZALnHfuIl8XoixmI5Uosq4z5A8tsPh9ZAWdQNY5HyTODu1gZDZD", null));

            this.setPosts();




            facebook.getGroups().forEach((a)->{
                System.out.println(a.getId());
                System.out.println(a.getName());
            });




        this.posts.forEach((v)->{

                PostUpdate pa = new PostUpdate(v.msg);
                pa.picture(v.img);
                pa.setCaption(v.msg);
                pa.setDescription(v.desc);
                pa.setMessage(v.msg);
                pa.setLink(v.url);
                pa.name(new MD5().toString());

                try {
                    //facebook.postFeed(pa);
                    facebook.postGroupFeed("139181413478546", pa);
                } catch (FacebookException e) {
                    e.printStackTrace();
                }

            });

        return "hello";
    }

}
