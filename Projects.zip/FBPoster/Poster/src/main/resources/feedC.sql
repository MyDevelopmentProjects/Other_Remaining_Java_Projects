INSERT INTO `f_category` (`id`, `date_created`, `date_updated`, `title`) VALUES
(1, '2017-10-02 19:17:33', NULL, 'Politician'),
(2, '2017-10-02 19:17:33', NULL, 'Developer'),
(3, '2017-10-02 19:17:50', NULL, 'Manager'),
(4, '2017-10-02 19:17:50', NULL, 'Fighter'),
(5, '2017-10-02 19:18:23', NULL, 'President'),
(6, '2017-10-02 19:18:23', NULL, 'Professor');

INSERT INTO `f_country` (`id`, `date_created`, `date_updated`, `lat`, `lng`, `title`) VALUES
(1, '2017-10-02 19:14:20', NULL, '42.3029842', '41.1143392', 'Georgia'),
(2, '2017-10-02 19:14:20', NULL, '36.2455612', '-113.7275082', 'United States'),
(3, '2017-10-02 19:15:26', NULL, '46.1444512', '-2.4368994', 'France'),
(4, '2017-10-02 19:15:26', NULL, '51.0967989', '5.9674148', 'Germany');

INSERT INTO `f_city` (`id`, `date_created`, `date_updated`, `lat`, `lng`, `title`, `country_id`) VALUES
(1, '2017-10-02 19:16:16', NULL, '41.7326304', '44.6987681', 'Tbilisi', 1),
(2, '2017-10-02 19:16:16', NULL, '42.2547282', '42.6829771', 'Kutaisi', 1),
(3, '2017-10-02 19:17:16', NULL, '48.8589507', '2.27702', 'Paris', 3),
(4, '2017-10-02 19:17:16', NULL, '48.1550547', '11.4017519', 'Munich', 4);

INSERT INTO `f_permissions` (`id`, `date_created`, `date_updated`, `description`, `name`) VALUES
(1, '2017-10-02 19:18:36', NULL, NULL, 'SOMETHING');

INSERT INTO `f_role` (`id`, `date_created`, `date_updated`, `name`) VALUES
(1, '2017-10-02 19:18:45', NULL, 'PAGE_USER');

INSERT INTO `f_role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1);

INSERT INTO `f_user` (`id`, `date_created`, `date_updated`, `about_me`, `is_active`, `dob`, `email`, `first_name`, `gender`, `img_url`, `last_name`, `password`, `phone`, `registration_is_verified`, `username`, `is_verified`, `category_id`, `city_id`, `role_id`) VALUES
(1, '2017-10-02 15:21:03', NULL, 'About pages are hard. You have one page to summarize who you are, what you do, and how you’re different in a clear, concise, and confident way. No big deal! Just tell us why you matter in two to five paragraphs, without bragging.\r\nHonestly, I don’t know anyone who enjoys this process. Even if you’re comfortable writing about yourself, it’s hard to know where to start or what to leave out. You know yourself better than anyone, but that only seems to make it worse.', b'1', '1990-11-28', 'gvashakidze6@gmail.com', 'George', b'1', 'http://static2.businessinsider.com/image/5899ffcf6e09a897008b5c04-1200/.jpg', 'Vashakidze', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995577651100', b'1', 'Vashusha', b'1', 1, 1, 1),
(2, '2017-10-02 15:21:03', NULL, 'The wise man Mindia in the epic Snake-Eater (1901, Russian translation 1934) dies because he cannot reconcile his ideals with the needs of his family and those of society. The catalytic plot device of Mindia''s consumption of serpent''s flesh in an attempt at suicide – which results instead in his obtaining of occult knowledge, constitutes a literary employment of the central, folk tale motif present in The White Snake (Brothers Grimm) which epitomizes tale type 673 in the Aarne-Thompson classification system.', b'1', '1987-01-11', 'iraklivasha@gmail.com', 'Irakli', b'1', 'https://cdn2.f-cdn.com/files/download/24619452/natural+background.png', 'Vashakidze', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995577051119', b'1', 'IrakliVasha', b'1', 3, 1, 1),
(3, '2017-10-02 15:21:03', NULL, 'The wise man Mindia in the epic Snake-Eater (1901, Russian translation 1934) dies because he cannot reconcile his ideals with the needs of his family and those of society. The catalytic plot device of Mindia''s consumption of serpent''s flesh in an attempt at suicide – which results instead in his obtaining of occult knowledge, constitutes a literary employment of the central, folk tale motif present in The White Snake (Brothers Grimm) which epitomizes tale type 673 in the Aarne-Thompson classification system.', b'1', '1987-01-11', 'nikovasha@gmail.com', 'NiCo', b'1', 'http://www.xsjjys.com/data/out/96/WHDQ-512397052.jpg', 'Vashakidze', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995577051119', b'1', 'NicoVasha', b'1', 4, 1, 1),
(4, '2017-10-02 15:21:03', NULL, 'The wise man Mindia in the epic Snake-Eater (1901, Russian translation 1934) dies because he cannot reconcile his ideals with the needs of his family and those of society. The catalytic plot device of Mindia''s consumption of serpent''s flesh in an attempt at suicide – which results instead in his obtaining of occult knowledge, constitutes a literary employment of the central, folk tale motif present in The White Snake (Brothers Grimm) which epitomizes tale type 673 in the Aarne-Thompson classification system.', b'1', '1987-01-11', 'teoda@gmail.com', 'Tea', b'1', 'https://upload.wikimedia.org/wikipedia/en/7/70/Shawn_Tok_Profile.jpg', 'MsXis', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995577051119', b'1', 'TeaDa', b'1', 1, 1, 1),
(5, '2017-10-02 15:21:03', NULL, 'The wise man Mindia in the epic Snake-Eater (1901, Russian translation 1934) dies because he cannot reconcile his ideals with the needs of his family and those of society. The catalytic plot device of Mindia''s consumption of serpent''s flesh in an attempt at suicide – which results instead in his obtaining of occult knowledge, constitutes a literary employment of the central, folk tale motif present in The White Snake (Brothers Grimm) which epitomizes tale type 673 in the Aarne-Thompson classification system.', b'1', '1987-01-11', 'atomicD@gmail.com', 'Atomic', b'1', 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Pablo_Schreiber_2011_Shankbone.JPG/440px-Pablo_Schreiber_2011_Shankbone.JPG', 'Fasus', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995571987612', b'1', 'Fasus', b'1', 2, 1, 1),
(6, '2017-10-02 15:21:03', NULL, 'The wise man Mindia in the epic Snake-Eater (1901, Russian translation 1934) dies because he cannot reconcile his ideals with the needs of his family and those of society. The catalytic plot device of Mindia''s consumption of serpent''s flesh in an attempt at suicide – which results instead in his obtaining of occult knowledge, constitutes a literary employment of the central, folk tale motif present in The White Snake (Brothers Grimm) which epitomizes tale type 673 in the Aarne-Thompson classification system.', b'1', '1987-01-11', 'LafusTemal@gmail.com', 'Lafus', b'1', 'http://images6.fanpop.com/image/photos/38500000/Dean-Winchester-salvatore-girls-and-winchester-girls-38503609-730-1095.jpg', 'Temal', '$2a$10$R.CiPGwEFxyol7OMPvDAren0t8zYwa7FH49hVZqCeZ9fQaouGOEG6', '+995571987612', b'1', 'Temal', b'1', 2, 1, 1);

INSERT INTO `f_feed` (`id`, `date_created`, `date_updated`, `title`, `city_id`) VALUES
(1, '2017-10-02 19:21:43', NULL, 'Georgia Feed', 1),
(2, '2017-10-02 19:21:43', NULL, 'France Feed', 3);

INSERT INTO `f_post` (`id`, `date_created`, `date_updated`, `img_url`, `lat`, `lng`, `text`, `feed_id`, `user_id`) VALUES
(1, '2017-10-02 19:23:16', NULL, 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/Mosque_in_Tbilisi.jpg/800px-Mosque_in_Tbilisi.jpg', '41.7260122', '44.7481674', 'Vazha-Pshavela was born into a family of clergymen in the little village of Chargali, situated in the mountainous Pshavi province of Eastern Georgia.', 1, 1),
(2, '2017-10-02 19:23:16', NULL, 'https://media.timeout.com/images/103817003/image.jpg', '41.7260122', '44.7481674', 'Paris (locally [pɑʁi] (About this sound listen)) is the capital and most populous city of France, with an administrative-limits area of 105 square kilometres (41 square miles) and a 2015 population of 2,229,621.[2]', 1, 1);

INSERT INTO `f_post_comments` (`id`, `date_created`, `date_updated`, `text`, `post_id`, `user_id`) VALUES
(1, '2017-10-02 19:23:48', NULL, 'Vazha-Pshavela embarked on his literary career in the mid-1880s. In his works, he portrayed the everyday life and psychology of his contemporary Pshavs. Vazha-Pshavela is the author of many world-class literary works – 36 epics, about 400 poems ("Aluda Ketelauri", "Bakhtrioni", "Gogotur and Apshina", "Host and Guest", "Snake eater", "Eteri", "Mindia", etc.), plays, and stories, as well as literary criticism, journalism and scholarly articles of ethnographic interest. Even in his fiction he evokes the life of the Georgian highlander with a near-ethnographic precision and depicts an entire world of mythological concepts. In his poetry, the poet addresses the heroic past of his people and extols the struggle against enemies both external and internal. (poems A Wounded Snow Leopard (1890), A Letter of a Pshav Soldier to His Mother (1915), etc.).', 1, 1),
(2, '2017-10-02 19:23:48', NULL, 'In the best of his epic compositions, Vazha-Pshavela deals powerfully with the problems raised by the interaction of the individual with society, of humankind with the natural world and of human love with love of country. The conflict between an individual and a temi (community) is depicted in the epics Aluda Ketelauri (1888, Russian translation, 1939) and Guest and Host (1893, Russian translation 1935). The principal characters in both works come to question and ultimately to disregard outdated laws upheld by their respective communities,in their personal journey toward a greater humanity that transcends the merely parochial.', 1, 1),
(3, '2017-10-02 19:26:56', NULL, 'Vazha-Pshavela is also unrivalled in the field of Georgian poetry in his idiosyncratic and evocative depictions of Nature – for which he felt a deep love.His landscapes are full of motion and internal conflicts. His poetic diction is saturated with all the riches of his native tongue, and yet this is an impeccably exact literary language. Thanks to excellent translations into Russian (by Nikolay Zabolotsky, V. Derzhavin, Osip Mandelshtam, Boris Pasternak, S. Spassky, Marina Tsvetaeva, and others),into English (by Donald Rayfield, Venera Urushadze, Lela Jgerenaia, Nino Ramishvili, and others),into French (by Gaston Bouatchidzé), and into German (by Yolanda Marchev, Steffi Chotiwari-Jünger), the poet''s work has found the wider audience that it undoubtedly deserves. Furthermore, Vazha-Pshavela''s compositions have also become available to representatives of other nationalities of the ex-USSR. To date, his poems and narrative compositions have been published in more than 20 languages', 1, 2),
(4, '2017-10-02 19:27:09', NULL, 'Vazha-Pshavela died in Tiflis on 10 July 1915 and was buried there,in the ancient capital city of his native land, being accorded the signal honour of a tomb in the prestigious Pantheon of the Mtatsminda Mountain, in recognition both of his literary achievements and his role as a representative of the National Liberation movement of Georgia.', 1, 1);

INSERT INTO `f_post_likes` (`id`, `date_created`, `date_updated`, `post_id`, `user_id`) VALUES
(1, '2017-10-02 19:23:56', NULL, 1, 1),
(4, '2017-10-02 19:26:23', NULL, 1, 2);

INSERT INTO `f_tags` (`id`, `date_created`, `date_updated`, `title`) VALUES
(1, '2017-10-02 19:24:25', NULL, '#Georgia'),
(2, '2017-10-02 19:24:25', NULL, '#SAQARTVELO'),
(3, '2017-10-02 19:27:29', NULL, '#Beaufy'),
(4, '2017-10-02 19:27:29', NULL, '#Saburtalo'),
(5, '2017-10-02 19:27:36', NULL, '#Siyvaruli'),
(6, '2017-10-02 19:27:36', NULL, '#Sex'),
(7, '2017-10-02 19:27:42', NULL, '#Funny'),
(8, '2017-10-02 19:27:42', NULL, '#Joy');

INSERT INTO `f_post_tags` (`id`, `date_created`, `date_updated`, `created_by`, `post_id`, `tag_id`, `tagged`) VALUES
(1, '2017-10-02 19:24:49', NULL, 1, 1, 1, 1),
(2, '2017-10-02 19:26:40', NULL, 2, 1, 2, 1);