package ge.mgl.entities;

import javax.persistence.*;

/**
 * Created by MJaniko on 3/8/2017.
 */
@Entity
@Table(name = "f_country")
public class FCountry extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "title")
    private String title;

    @Column(name = "lat")
    private String lat;

    @Column(name = "lng")
    private String lng;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }
}

