package ge.mgl.dao;

import ge.mgl.entities.FPostTags;
import ge.mgl.entities.FTags;
import ge.mgl.utils.MGLStringUtils;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class FPostTagsDAO extends PaginationAndFullSearchQuery<FPostTags> {

    public FPostTagsDAO() {
        super(FPostTags.class);
    }

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FPostTags> criteriaQuery = criteriaBuilder.createQuery(FPostTags.class);
        Root<FPostTags> returnClassRoot = criteriaQuery.from(FPostTags.class);
        returnClassRoot.alias(TABLE_ALIAS);

        List<Predicate> exprs = new ArrayList<>();

        if(objects != null){
            if (objects.length > 0 && objects[0] != null) {
                if (!MGLStringUtils.IsNullOrBlank(objects[0].toString())) {
                    FTags tag = getTagByName(objects[0].toString());
                    if (tag != null) {
                        exprs.add(criteriaBuilder.equal(returnClassRoot.get("tag").get("id"), tag.getId()));
                    }
                }
            }
        }

        if(exprs.size() > 0){
            return criteriaBuilder.and(exprs.toArray(new Predicate[exprs.size()]));
        }

        return null;
    }

    public FTags getTagByName(String name){
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<FTags> cq = cb.createQuery(FTags.class);
        Root<FTags> rootEntry = cq.from(FTags.class);
        CriteriaQuery<FTags> all = cq.select(rootEntry).where(
                cb.equal(rootEntry.get("title"), name)
        );
        TypedQuery<FTags> allQuery = getEntityManager().createQuery(all);
        List<FTags> resultList = allQuery.getResultList();
        return  (!resultList.isEmpty()) ? resultList.get(0) : null;
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {

        return null;
    }
}
