package ge.mgl.controller.old;

public class UserController {

//    @RequestMapping(method = RequestMethod.GET)
//    public String userPage(Model model){
//        if(UserUtils.currentUser() == null && !UserUtils.isAuthenticated()){
//            return "redirect:/";
//        }
//        model.addAttribute("user", UserUtils.currentUser());
//        model.addAttribute("content", "user-page");
//        UtilContact.contactToModel(model, contactService.getAll());
//        UtilCategory.categoryToModel(model, categoryService.getAll());
//        JSGeneratorUtil.GenerateJS(model, "/js/controller/UserController.js");
//        return "index";
//    }


}
