package ge.mgl.entities.translation;

/**
 * Created by Mikheil on 4/25/2017.
 */
public abstract class Translation {
}
