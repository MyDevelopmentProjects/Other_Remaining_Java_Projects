package ge.mgl.dao.old;

import ge.mgl.entities.old.WhyChooseUs;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by MJaniko on 4/1/2017.
 */
@Repository
public class WhyChooseUsDAO extends PaginationAndFullSearchQuery<WhyChooseUs> {

    public WhyChooseUsDAO(){
        super(WhyChooseUs.class);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return null;
    }
}
