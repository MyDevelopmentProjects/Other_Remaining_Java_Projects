package ge.mgl.enums;

/**
 * Created by georgevashakidze on 8/10/17.
 */
public enum EFReportedPostType {

    IT_IS_SPAM,
    IT_HAS_SEXUAL_DESCRIPTION,
    I_DO_NOT_WANT_TO_SEE_IT;

    public static EFReportedPostType findByName(String name){
        for(EFReportedPostType dat : values()){
            if(dat.name().equals(name)){
                return dat;
            }
        }
        return null;
    }

}
