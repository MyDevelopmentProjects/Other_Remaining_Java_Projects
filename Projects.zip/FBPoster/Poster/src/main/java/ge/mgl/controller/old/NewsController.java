package ge.mgl.controller.old;

import ge.mgl.entities.old.News;
import ge.mgl.entities.old.Slider;
import ge.mgl.enums.ESliderSection;
import ge.mgl.service.old.NewsService;
import ge.mgl.service.old.SliderService;
import ge.mgl.utils.GeneralUtil;
import ge.mgl.utils.RequestResponse;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.stream.Collectors;

import static ge.mgl.utils.constants.Constants.ControllerCodes.*;
import static ge.mgl.utils.constants.Constants.ControllerCodes.PAGE_NUMBER_DEFAULT_VALUE;
import static ge.mgl.utils.constants.Constants.ControllerCodes.PAGE_SIZE_DEFAULT_VALUE;

/**
 * Created by MJaniko on 3/9/2017.
 */
@Controller
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @Autowired
    private SliderService sliderService;

    @RequestMapping(method = RequestMethod.GET)
    public String news(Model model,
                       @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
                       @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
                       @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
                       @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
                       @RequestParam(required = false, defaultValue = "6") int pageSize){
        model.addAttribute("content", "news");
        model.addAttribute("innerBody", "true");
        model.addAttribute("pageTitle", "title.news");
        model.addAttribute("sliderList", getTopSection(ESliderSection.NEWS_PAGE_TOP_SECTION));
        model.addAttribute("data", newsService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize));
        return "index";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return newsService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    private List<Slider> getTopSection(ESliderSection section) {
        List<Slider> list = sliderService.getAll();
        return list.stream().filter(obj-> obj.getSection().equals(section)).collect(Collectors.toList());
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public String more(Model model, @PathVariable("id") Long id, HttpServletRequest request) {

        News n = newsService.find(id);
        if (n == null) {
            return "redirect:/";
        }
        model.addAttribute("content", "more");
        model.addAttribute("data", n);

        String lang = "en";
        Object obj = request.getSession().getAttribute("language");
        if (obj != null) {
            lang = obj.toString();
        }

        model.addAttribute("pageTitle", lang.equals("en") ? n.getDetails().getTitleEN() : n.getDetails().getTitleRU());
        return "index";
    }

    @RequestMapping(value = SLASH + PUT, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse save(@RequestBody News news) {
        newsService.save(news);
        return GeneralUtil.RequestSuccess();
    }
}
