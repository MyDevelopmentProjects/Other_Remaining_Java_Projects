
package ge.mgl.service.old;

import ge.mgl.dao.old.TourDAO;
import ge.mgl.dto.TourDTO;
import ge.mgl.entities.FCity;
import ge.mgl.entities.old.Tour;
import ge.mgl.utils.GeneralUtil;
import ge.mgl.utils.SEOUtil;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by MJaniko on 3/31/2017.
 */
@Service
public class TourService {

    @Autowired
    private TourDAO tourDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TourDTO> getSearchList(
            String searchExpression,
            String sortField,
            boolean isAscending,
            Integer pageNumber,
            int pageSize,
            int category,
            int minPrice,
            int maxPrice,
            int adult,
            int child,
            int period,
            String startDate,
            String endDate) {
        return tourDAO.getPaginatedList(Tour.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize,category,minPrice,
                maxPrice,adult,child,period,startDate,endDate
        ).transform(TourDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TourDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return tourDAO.getPaginatedList(Tour.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(TourDTO.class);
    }

    @Transactional(readOnly = true)
    public List<Tour> getAll(){
        return tourDAO.all();
    }

    @Transactional(readOnly = true)
    public Tour getById(Long id){
        return tourDAO.find(id);
    }

    @Transactional(readOnly = true)
    public List<Tour> getFirstThree(){
        return tourDAO.all().stream().limit(3).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<Tour> getToursByCity(Long id, FCity FCity){
        return tourDAO.getToursByCity(id, FCity);
    }

    @Transactional
    public Tour save(Tour tour) {
        tour.setLinks(SEOUtil.generatedSEO(tour.getTranslation()));
        tour.setPeriod(GeneralUtil.getDaysDifference(tour.getStartDate().getTime(), tour.getEndDate().getTime()));
        if (tour.getId() != null) {
            return tourDAO.update(tour);
        }
        return tourDAO.create(tour);
    }

    @Transactional
    public boolean delete(Long id) {
        return tourDAO.delete(id);
    }
}
