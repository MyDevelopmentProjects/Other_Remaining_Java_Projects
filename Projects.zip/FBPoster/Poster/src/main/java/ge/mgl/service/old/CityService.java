package ge.mgl.service.old;

import ge.mgl.dao.old.CityDAO;
import ge.mgl.dto.CityDTO;
import ge.mgl.entities.FCity;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by MJaniko on 3/8/2017.
 */
@Service
public class CityService {

    @Autowired
    private CityDAO countryDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CityDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return countryDAO.getPaginatedList(FCity.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(CityDTO.class);
    }
}
