package ge.mgl.service.old;

import ge.mgl.dao.old.NewsDAO;
import ge.mgl.entities.old.News;
import ge.mgl.entities.old.ServiceNews;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by MJaniko on 3/9/2017.
 */
@Service
public class NewsService {

    @Autowired
    private NewsDAO newsDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return newsDAO.getPaginatedList(News.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize);
    }

    public List<ServiceNews> getServiceNews() {
        return newsDAO.getServiceNews();
    }

    @Transactional(readOnly = true)
    public News find(Long id){
        return newsDAO.find(id);
    }

    @Transactional(readOnly = true)
    public List<News> getLastX(int number){
        return newsDAO.lastX(number);
    }

    @Transactional
    public News save(News about) {
        if (about.getId() != null) {
            return newsDAO.update(about);
        }
        return newsDAO.create(about);
    }

    @Transactional
    public boolean delete(Long id) {
        return newsDAO.delete(id);
    }
}
