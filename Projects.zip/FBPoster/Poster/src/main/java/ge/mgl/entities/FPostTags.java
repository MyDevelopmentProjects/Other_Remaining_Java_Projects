package ge.mgl.entities;

import javax.persistence.*;

@Entity
@Table(name = "f_post_tags")
public class FPostTags extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "created_by", nullable = false)
    private FUser createdBy;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "tagged", nullable = false)
    private FUser tagged;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "post_id", nullable = false)
    private FPost post;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "tag_id", nullable = false)
    private FTags tag;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FUser getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(FUser createdBy) {
        this.createdBy = createdBy;
    }

    public FUser getTagged() {
        return tagged;
    }

    public void setTagged(FUser tagged) {
        this.tagged = tagged;
    }

    public FPost getPost() {
        return post;
    }

    public void setPost(FPost post) {
        this.post = post;
    }

    public FTags getTag() {
        return tag;
    }

    public void setTag(FTags tag) {
        this.tag = tag;
    }
}

