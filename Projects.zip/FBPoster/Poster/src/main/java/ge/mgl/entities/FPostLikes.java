package ge.mgl.entities;

import javax.persistence.*;

@Entity
@Table(name = "f_post_likes")
public class FPostLikes extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private FUser user;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "post_id", nullable = false)
    private FPost post;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FUser getUser() {
        return user;
    }

    public void setUser(FUser user) {
        this.user = user;
    }

    public FPost getPost() {
        return post;
    }

    public void setPost(FPost post) {
        this.post = post;
    }
}

