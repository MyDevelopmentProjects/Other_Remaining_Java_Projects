package ge.mgl.dao.old;

import ge.mgl.entities.FCity;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by MJaniko on 3/8/2017.
 */
@Repository
public class CityDAO extends PaginationAndFullSearchQuery<FCity> {

    public CityDAO() {
        super(FCity.class);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return null;
    }
}
