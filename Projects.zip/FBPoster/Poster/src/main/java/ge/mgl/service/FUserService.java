package ge.mgl.service;

import ge.mgl.dao.FUserDAO;
import ge.mgl.entities.FUser;
import ge.mgl.utils.RequestResponse;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FUserService {

    @Autowired
    private FUserDAO userDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return userDAO.getPaginatedList(FUser.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize);
    }

    @Transactional
    public FUser loadUserByUsername(String username) {
        return userDAO.findByUserName(username);
    }


    @Transactional(readOnly = true)
    public FUser findUserByUsernamePassword(String username, String password) {
        return userDAO.findUserByUsernamePassword(username,password);
    }

    @Transactional
    public RequestResponse register(FUser user){
        return userDAO.register(user);
    }


    @Transactional
    public FUser save(FUser user) {
        if (user.getId() != null) {
            return userDAO.update(user);
        }
        return userDAO.create(user);
    }


    @Transactional(readOnly = true)
    public FUser findById(Long id){
        return userDAO.find(id);
    }

    @Transactional
    public boolean delete(Long id) {
        return userDAO.delete(id);
    }
}
