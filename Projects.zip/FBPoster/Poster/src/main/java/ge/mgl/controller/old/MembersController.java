package ge.mgl.controller.old;

import ge.mgl.entities.old.About;
import ge.mgl.service.old.*;
import ge.mgl.utils.GeneralUtil;
import ge.mgl.utils.RequestResponse;
import ge.mgl.utils.UtilCategory;
import ge.mgl.utils.UtilContact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import static ge.mgl.utils.constants.Constants.ControllerCodes.PUT;
import static ge.mgl.utils.constants.Constants.ControllerCodes.SLASH;

/**
 * Created by MJaniko on 3/9/2017.
 */
@Controller
@RequestMapping("/members")
public class MembersController {

    @Autowired
    private ContactService contactService;

    @Autowired
    private AboutService aboutService;

    @Autowired
    private OurTeamService ourTeamService;

    @Autowired
    private WhyChooseUsService whyChooseUsService;

    @Autowired
    private CategoryService categoryService;

    @RequestMapping(method = RequestMethod.GET)
    public String members(Model model){
        model.addAttribute("content", "members");
        model.addAttribute("innerBody", "true");
        model.addAttribute("pageTitle", "title.members");
        model.addAttribute("aboutData", aboutService.first());
        model.addAttribute("ourTeamList", ourTeamService.getFirstThree());
        model.addAttribute("chooseUsList", whyChooseUsService.getFirstThree());
        UtilCategory.categoryToModel(model, categoryService.getAll());
        UtilContact.contactToModel(model, contactService.getAll());
        return "index";
    }


    @RequestMapping(value = "/id/{id}", method = RequestMethod.GET)
    @ResponseBody
    public About getFirstElement(@PathVariable("id") Long id){
        return aboutService.first();
    }

    @RequestMapping(value = SLASH + PUT, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse save(@RequestBody About about) {
        aboutService.save(about);
        return GeneralUtil.RequestSuccess();
    }
}
