package ge.mgl.service;

import ge.mgl.dao.FFeedDAO;
import ge.mgl.dao.FUserDAO;
import ge.mgl.entities.FFeed;
import ge.mgl.entities.FUser;
import ge.mgl.utils.RequestResponse;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FFeedService {

    @Autowired
    private FFeedDAO feedDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return feedDAO.getPaginatedList(FFeed.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize);
    }

    @Transactional
    public FFeed save(FFeed feed) {
        if (feed.getId() != null) {
            return feedDAO.update(feed);
        }
        return feedDAO.create(feed);
    }

    @Transactional(readOnly = true)
    public FFeed findById(Long id){
        return feedDAO.find(id);
    }

    @Transactional
    public boolean delete(Long id) {
        return feedDAO.delete(id);
    }
}
