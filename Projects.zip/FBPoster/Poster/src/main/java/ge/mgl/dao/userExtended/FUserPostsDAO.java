package ge.mgl.dao.userExtended;

import ge.mgl.entities.FPost;
import ge.mgl.security.UserUtils;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class FUserPostsDAO extends PaginationAndFullSearchQuery<FPost> {

    public FUserPostsDAO() {
        super(FPost.class);
    }


    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FPost> criteriaQuery = criteriaBuilder.createQuery(FPost.class);
        Root<FPost> returnClassRoot = criteriaQuery.from(FPost.class);
        returnClassRoot.alias(TABLE_ALIAS);

        List<Predicate> exprs = new ArrayList<>();

        exprs.add(criteriaBuilder.equal(returnClassRoot.get("user").get("id"), UserUtils.currentUser().getId()));

        if(objects != null){
            if (objects.length > 0 && objects[0] instanceof Integer) {
                if((int) objects[0] > 0){
                    //exprs.add(criteriaBuilder.equal(returnClassRoot.get("starCount"), objects[0]));
                }
            }
            /*if (objects.length > 9 && objects[9] instanceof Integer) {
                if((int) objects[9] > 0){
                    exprs.add(criteriaBuilder.equal(returnClassRoot.get("att").get("gym"), objects[9]));
                }
            }*/
        }

        if(exprs.size() > 0){
            return criteriaBuilder.and(exprs.toArray(new Predicate[exprs.size()]));
        }
        return null;
    }













    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<>();
        if (resultClass == FPost.class) {
            //fieldList.add("");
        }
        return fieldList;
    }
}
