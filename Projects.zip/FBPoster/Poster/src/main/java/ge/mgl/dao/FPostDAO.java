package ge.mgl.dao;

import ge.mgl.entities.FPost;
import ge.mgl.security.UserUtils;
import ge.mgl.utils.MGLStringUtils;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class FPostDAO extends PaginationAndFullSearchQuery<FPost> {

    public FPostDAO() {
        super(FPost.class);
    }

    @SuppressWarnings("uncheked")
    public List<FPost> getNearestPosts(String lat, String lng, String distance) {
        try {
            if (MGLStringUtils.IsNullOrBlank(distance)) distance = "5";
            return (List<FPost>) getEntityManager().createQuery("FROM FPost d WHERE calcDist(:lat,:lng, d.lat, d.lng) <= :distance ORDER BY calcDist(:lat,:lng, d.lat, d.lng) ASC")
                    .setParameter("distance", distance)
                    .setParameter("lat", lat)
                    .setParameter("lng", lng)
                    .getResultList();
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
        return null;
    }

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<FPost> criteriaQuery = criteriaBuilder.createQuery(FPost.class);
        Root<FPost> returnClassRoot = criteriaQuery.from(FPost.class);
        returnClassRoot.alias(TABLE_ALIAS);

        List<Predicate> exprs = new ArrayList<>();

        if(objects != null){
            if (objects.length > 0 && objects[0] instanceof Long) {
                if((int) objects[0] > 0){
                    exprs.add(criteriaBuilder.equal(returnClassRoot.get("feed").get("id"), objects[0]));
                }
            }
            /*if (objects.length > 9 && objects[9] instanceof Integer) {
                if((int) objects[9] > 0){
                    exprs.add(criteriaBuilder.equal(returnClassRoot.get("att").get("gym"), objects[9]));
                }
            }*/
        }

        if(exprs.size() > 0){
            return criteriaBuilder.and(exprs.toArray(new Predicate[exprs.size()]));
        }
        return null;
    }


    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {

        return null;
    }
}
