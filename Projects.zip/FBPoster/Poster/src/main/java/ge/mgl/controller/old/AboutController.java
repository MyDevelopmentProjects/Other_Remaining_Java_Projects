package ge.mgl.controller.old;

import ge.mgl.entities.old.About;
import ge.mgl.entities.old.Slider;
import ge.mgl.enums.ESliderSection;
import ge.mgl.service.old.AboutService;
import ge.mgl.service.old.SliderService;
import ge.mgl.utils.GeneralUtil;
import ge.mgl.utils.RequestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.stream.Collectors;

import static ge.mgl.utils.constants.Constants.ControllerCodes.PUT;
import static ge.mgl.utils.constants.Constants.ControllerCodes.SLASH;

/**
 * Created by MJaniko on 3/9/2017.
 */
@Controller
@RequestMapping("/about-us")
public class AboutController {

    @Autowired
    private AboutService aboutService;

    @Autowired
    private SliderService sliderService;

    @RequestMapping(method = RequestMethod.GET)
    public String about(Model model){
        model.addAttribute("content", "about-us");
        model.addAttribute("innerBody", "true");
        model.addAttribute("pageTitle", "title.about-us");
        model.addAttribute("data", aboutService.first());
        model.addAttribute("sliderList", getTopSection(ESliderSection.ABOUT_PAGE_TOP_SECTION));
        return "index";
    }

    private List<Slider> getTopSection(ESliderSection section) {
        List<Slider> list = sliderService.getAll();
        return list.stream().filter(obj-> obj.getSection().equals(section)).collect(Collectors.toList());
    }

    @RequestMapping(value = SLASH + PUT, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse save(@RequestBody About about) {
        aboutService.save(about);
        return GeneralUtil.RequestSuccess();
    }
}
