package ge.mgl.entities.old;

import ge.mgl.entities.SuperModel;
import ge.mgl.entities.translation.TitleDescriptionTranslation;

import javax.persistence.*;

/**
 * Created by MJaniko on 4/1/2017.
 */
/*@Entity
@Table(name = "why_choose_us")*/
public class WhyChooseUs extends SuperModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "icon")
    private String icon;

    @Embedded
    private TitleDescriptionTranslation translation;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public TitleDescriptionTranslation getTranslation() {
        return translation;
    }

    public void setTranslation(TitleDescriptionTranslation translation) {
        this.translation = translation;
    }
}
