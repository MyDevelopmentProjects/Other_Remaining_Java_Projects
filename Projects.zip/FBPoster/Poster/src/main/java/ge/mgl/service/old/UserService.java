package ge.mgl.service.old;

import ge.mgl.dao.old.UserDAO;
import ge.mgl.dto.UserDTO;
import ge.mgl.entities.old.User;
import ge.mgl.utils.RequestResponse;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    @Autowired
    private UserDAO userDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<UserDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return userDAO.getPaginatedList(User.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(UserDTO.class);
    }

    @Transactional
    public User loadUserByUsername(String username) {
        return userDAO.findByUserName(username);
    }


    @Transactional(readOnly = true)
    public User findUserByUsernamePassword(String username, String password) {
        return userDAO.findUserByUsernamePassword(username,password);
    }

    @Transactional
    public RequestResponse register(User user){
        return userDAO.register(user);
    }


    @Transactional
    public User save(User user) {
        if (user.getId() != null) {
            return userDAO.update(user);
        }
        return userDAO.create(user);
    }


    @Transactional(readOnly = true)
    public User findById(Long id){
        return userDAO.find(id);
    }

    @Transactional
    public boolean delete(Long id) {
        return userDAO.delete(id);
    }
}
