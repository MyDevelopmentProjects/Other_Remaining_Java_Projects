package ge.mgl.dao;

import ge.mgl.entities.FTags;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class FTagsDAO extends PaginationAndFullSearchQuery<FTags> {

    public FTagsDAO() {
        super(FTags.class);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {

        return null;
    }
}
