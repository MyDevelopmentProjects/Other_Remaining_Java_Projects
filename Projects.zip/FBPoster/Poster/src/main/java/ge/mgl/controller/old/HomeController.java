package ge.mgl.controller.old;

import ge.mgl.entities.old.Slider;
import ge.mgl.enums.ESliderSection;
import ge.mgl.service.old.NewsService;
import ge.mgl.service.old.SliderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.social.connect.ConnectionRepository;
import org.springframework.social.facebook.api.Facebook;
import org.springframework.social.facebook.api.PagedList;
import org.springframework.social.facebook.api.Post;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Created by MJaniko on 3/10/2017.
 */
@Controller
public class HomeController {

    @Autowired
    private Facebook facebook;
    @Autowired
    private ConnectionRepository connectionRepository;

    @RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public String home(Model model) {
        return "index";
    }

    @RequestMapping(value = {"/fb"}, method = RequestMethod.GET)
    public String helloFacebook(Model model) {

        if (connectionRepository.findPrimaryConnection(Facebook.class) == null) {
            System.out.println("FACEBOOK IS NULL");
            return "redirect:/connect/facebook";
        }
        System.out.println("FACEBOOK IS INITIALIZED");

        model.addAttribute("facebookProfile", facebook.userOperations().getUserProfile());
        PagedList<Post> feed = facebook.feedOperations().getFeed();
        model.addAttribute("feed", feed);
        return "fb";
    }

}

