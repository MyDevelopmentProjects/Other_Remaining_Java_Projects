package ge.mgl.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "f_user")
public class FUser extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "city_id", nullable = false)
    private FCity city;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id", nullable = false)
    private FCategory category;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private FRole role;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "password", nullable = false)
    @JsonIgnore
    private String password;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "email", nullable = false)
    private String email;

    @Column(name = "phone")
    private String phone;

    @Temporal(TemporalType.DATE)
    @Column(name = "dob")
    private Date dob;

    @Column(name = "img_url")
    private String imgUrl;

    @Lob
    @Column(name = "about_me")
    private String aboutMe;

    @Column(name = "gender", columnDefinition = "bit(1) DEFAULT 0")
    private boolean gender = false; //false = კაცი, true = ქალი

    @Column(name = "is_active", columnDefinition = "bit(1) DEFAULT 1")
    private boolean active = true;

    @Column(name = "is_verified", columnDefinition = "bit(1) DEFAULT 0")
    private boolean verified = false;

    @Column(name = "registration_is_verified", columnDefinition = "bit(1) DEFAULT 0")
    private boolean registrationVerified = false;


    public FUser() {
    }

    public FUser(FUser user) {
        this.id = user.id;
        this.role = user.role;
        this.city = user.city;
        this.category = user.category;
        this.username = user.username;
        this.password = user.password;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
        this.email = user.email;
        this.aboutMe = user.aboutMe;
        this.phone = user.phone;
        this.imgUrl = user.imgUrl;
        this.dob = user.dob;
        this.gender = user.gender;
        this.active = user.active;
        this.verified = user.verified;
        this.registrationVerified = user.registrationVerified;
        this.dateCreated = user.dateCreated;
        this.dateUpdated = user.dateUpdated;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public FCity getCity() {
        return city;
    }

    public void setCity(FCity city) {
        this.city = city;
    }

    public FCategory getCategory() {
        return category;
    }

    public void setCategory(FCategory category) {
        this.category = category;
    }

    public FRole getRole() {
        return role;
    }

    public void setRole(FRole role) {
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public boolean getGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public boolean getActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getVerified() {
        return verified;
    }

    public void setVerified(boolean verified) {
        this.verified = verified;
    }

    public boolean getRegistrationVerified() {
        return registrationVerified;
    }

    public void setRegistrationVerified(boolean registrationVerified) {
        this.registrationVerified = registrationVerified;
    }
}
