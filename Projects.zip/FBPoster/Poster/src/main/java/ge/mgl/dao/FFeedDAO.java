package ge.mgl.dao;

import ge.mgl.entities.FFeed;
import ge.mgl.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FFeedDAO extends PaginationAndFullSearchQuery<FFeed> {

    public FFeedDAO() {
        super(FFeed.class);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        return null;
    }
}
