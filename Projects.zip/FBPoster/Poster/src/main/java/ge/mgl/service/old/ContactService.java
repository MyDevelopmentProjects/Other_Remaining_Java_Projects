package ge.mgl.service.old;

import ge.mgl.dao.old.ContactDAO;
import ge.mgl.dto.ContactDTO;
import ge.mgl.entities.old.Contact;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by MJaniko on 3/12/2017.
 */
@Service
public class ContactService {

    @Autowired
    private ContactDAO contactDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<ContactDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return contactDAO.getPaginatedList(Contact.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(ContactDTO.class);
    }

    @Transactional(readOnly = true)
    public List<Contact> getAll(){
        return contactDAO.all();
    }

    @Transactional
    public Contact save(Contact contact) {
        if (contact.getId() != null) {
            return contactDAO.update(contact);
        }
        return contactDAO.create(contact);
    }

    @Transactional
    public boolean delete(Long id) {
        return contactDAO.delete(id);
    }

}
