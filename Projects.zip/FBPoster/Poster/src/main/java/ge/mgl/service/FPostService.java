package ge.mgl.service;

import ge.mgl.dao.FPostDAO;
import ge.mgl.entities.FPost;
import ge.mgl.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FPostService {

    @Autowired
    private FPostDAO postDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return postDAO.getPaginatedList(FPost.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize);
    }

    @Transactional
    public FPost save(FPost post) {
        if (post.getId() != null) {
            return postDAO.update(post);
        }
        return postDAO.create(post);
    }

    public List<FPost> getNearestPosts(String lat, String lng, String distance) {
        return postDAO.getNearestPosts(lat, lng, distance);
    }

    @Transactional(readOnly = true)
    public FPost findById(Long id){
        return postDAO.find(id);
    }

    @Transactional
    public boolean delete(Long id) {
        return postDAO.delete(id);
    }
}
