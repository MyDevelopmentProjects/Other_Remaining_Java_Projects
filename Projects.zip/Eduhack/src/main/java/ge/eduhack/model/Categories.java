package ge.eduhack.model;

import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;
import javax.validation.constraints.Size;

@Entity
@Table(name = "categories", catalog = "eduhack")
public class Categories extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Size(min = 2, max = 20)
    @Column(name = "name", columnDefinition = "VARCHAR(255) COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @Column(name = "image_url")
    private String imgUrl;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
}
