package ge.eduhack.model;

import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

@Entity
@Table(name = "training", catalog = "eduhack")
public class Training extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "name", columnDefinition = "text COLLATE utf8mb4_unicode_ci", nullable = false)
    private String name;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "city_id", nullable = false)
    private Cities city;

    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "created_by", nullable = false)
    private Users createdBy;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "category_id", nullable = false)
    private Categories category;

    @NotNull
    @Column(name = "date_from", nullable = false)
    private Date dateFrom;

    @NotNull
    @Column(name = "date_to", nullable = false)
    private Date dateTo;

    @Column(name = "is_payable", columnDefinition = "bit(1) DEFAULT 0")
    private boolean payable = false;

    @Column(name = "payable")
    private Double price;

    @Column(name = "short_description", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String shortDescription;

    @Column(name = "deep_description", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String deepDescription;

    @Column(name = "image_url")
    private String imgUrl;

    @Column(name = "is_approved", columnDefinition = "bit(1) DEFAULT 0")
    private boolean approved = false;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Cities getCity() {
        return city;
    }
    public void setCity(Cities city) {
        this.city = city;
    }
    public Categories getCategory() {
        return category;
    }
    public void setCategory(Categories category) {
        this.category = category;
    }
    public Date getDateFrom() {
        return dateFrom;
    }
    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }
    public Date getDateTo() {
        return dateTo;
    }
    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }
    public boolean getPayable() {
        return payable;
    }
    public void setPayable(boolean payable) {
        this.payable = payable;
    }
    public Double getPrice() {
        return price;
    }
    public void setPrice(Double price) {
        this.price = price;
    }
    public String getShortDescription() {
        return shortDescription;
    }
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }
    public String getDeepDescription() {
        return deepDescription;
    }
    public void setDeepDescription(String deepDescription) {
        this.deepDescription = deepDescription;
    }
    public String getImgUrl() {
        return imgUrl;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    public Users getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(Users createdBy) {
        this.createdBy = createdBy;
    }
    public boolean getApproved() {
        return approved;
    }
    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}
