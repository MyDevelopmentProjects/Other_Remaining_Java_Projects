package ge.eduhack.model;

import com.sun.istack.internal.NotNull;
import ge.eduhack.mappedsupperclass.SuperModel;
import org.hibernate.validator.constraints.Email;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "users", catalog = "eduhack")
public class Users extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "role_id", nullable = false)
    private Roles role;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "city_id", nullable = false)
    private Cities city;

    @Size(min = 2, max = 100)
    @Column(name = "name")
    private String name;

    @Size(min = 2, max = 30)
    @Column(name = "title")
    private String title;

    @Size(min = 2, max = 16)
    @Column(name = "username", unique = true, nullable = false, columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String userName;

    @Size(min = 2, max = 16)
    @Column(name = "password", nullable = false)
    private String password;

    @Size(min = 2, max = 20)
    @Column(name = "first_name", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String firstName;

    @Size(min = 2, max = 20)
    @Column(name = "last_name", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String lastName;

    @Size(min = 3, max = 300)
    @Column(name = "first_and_last", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String firstAndLast;

    @Size(min = 4, max = 50)
    @Email
    @Column(name = "email", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String email;

    @Column(name = "description", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String description;

    @Column(name = "address", columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String address;

    @Column(name = "dob", columnDefinition = "DATETIME NOT NULL DEFAULT '1920-01-01 12:00:00'")
    private Date dob;

    @Size(min = 3, max = 30)
    @Column(name = "m_number")
    private String mNumber;

    @Column(name = "star", columnDefinition = "bit(1) DEFAULT 0")
    private Short starValue = 0;

    @Column(name = "location")
    private String location;

    @Column(name = "web_page")
    private String webPage;

    @Column(name = "gender", columnDefinition = "bit(1) DEFAULT 0")
    private boolean gender = false;

    @Column(name = "is_active", columnDefinition = "bit(1) DEFAULT 0")
    private boolean active = false;

    @Column(name = "is_trainer", columnDefinition = "bit(1) DEFAULT 0")
    private boolean trainer = false;

    @Column(name = "is_super_admin", columnDefinition = "bit(1) DEFAULT 0")
    private boolean superAdmin = false;

    @Column(name = "image_url")
    private String imgUrl;

    @Transient
    private String gRecaptchaKey;

    @PrePersist
    void onCreate() {
        this.setDateCreated(new Timestamp((new Date()).getTime()));
        this.setFirstAndLast(this.getFirstName() + " " + this.getLastName());
    }

    @PreUpdate
    void onPersist() {
        this.setDateUpdated(new Timestamp((new Date()).getTime()));
        this.setFirstAndLast(this.getFirstName() + " " + this.getLastName());
    }

    public Users() {
    }

    public Users(Users user) {
        this.id = user.id;
        this.role = user.role;
        this.city = user.city;
        this.name = user.name;
        this.title = user.title;
        this.userName = user.userName;
        this.password = user.password;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
        this.firstAndLast = user.firstAndLast;
        this.email = user.email;
        this.description = user.description;
        this.address = user.address;
        this.dob = user.dob;
        this.mNumber = user.mNumber;
        this.starValue = user.starValue;
        this.location = user.location;
        this.webPage = user.webPage;
        this.gender = user.gender;
        this.active = user.active;
        this.trainer = user.trainer;
        this.superAdmin = user.superAdmin;
        this.imgUrl = user.imgUrl;
        this.dateCreated = user.dateCreated;
        this.dateUpdated = user.dateUpdated;
        this.dateDeleted = user.dateDeleted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Roles getRole() {
        return role;
    }

    public void setRole(Roles role) {
        this.role = role;
    }

    public Cities getCity() {
        return city;
    }

    public void setCity(Cities city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstAndLast() {
        return firstAndLast;
    }

    public void setFirstAndLast(String firstAndLast) {
        this.firstAndLast = firstAndLast;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getmNumber() {
        return mNumber;
    }

    public void setmNumber(String mNumber) {
        this.mNumber = mNumber;
    }

    public Short getStarValue() {
        return starValue;
    }

    public void setStarValue(Short starValue) {
        this.starValue = starValue;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getWebPage() {
        return webPage;
    }

    public void setWebPage(String webPage) {
        this.webPage = webPage;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isTrainer() {
        return trainer;
    }

    public void setTrainer(boolean trainer) {
        this.trainer = trainer;
    }

    public boolean isSuperAdmin() {
        return superAdmin;
    }

    public void setSuperAdmin(boolean superAdmin) {
        this.superAdmin = superAdmin;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getgRecaptchaKey() {
        return gRecaptchaKey;
    }

    public void setgRecaptchaKey(String gRecaptchaKey) {
        this.gRecaptchaKey = gRecaptchaKey;
    }
}
