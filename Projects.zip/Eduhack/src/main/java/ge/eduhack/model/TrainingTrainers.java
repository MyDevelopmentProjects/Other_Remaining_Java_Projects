package ge.eduhack.model;

import com.sun.istack.internal.NotNull;
import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "training_trainers", catalog = "eduhack")
public class TrainingTrainers extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "training", nullable = false)
    private Training training;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "training_object", nullable = false)
    private Users trainingObject;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Training getTraining() {
        return training;
    }
    public void setTraining(Training training) {
        this.training = training;
    }
    public Users getTrainingObject() {
        return trainingObject;
    }
    public void setTrainingObject(Users trainingObject) {
        this.trainingObject = trainingObject;
    }

}
