package ge.eduhack.model;

import com.sun.istack.internal.NotNull;
import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;

@Entity
@Table(name = "user_tags", catalog = "eduhack")
public class UserTags extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "tag_id", nullable = false)
    private Tags tag;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Users getUser() {
        return user;
    }
    public void setUser(Users user) {
        this.user = user;
    }
    public Tags getTag() {
        return tag;
    }
    public void setTag(Tags tag) {
        this.tag = tag;
    }

}
