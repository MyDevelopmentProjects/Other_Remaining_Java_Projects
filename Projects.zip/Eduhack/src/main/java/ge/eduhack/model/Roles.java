package ge.eduhack.model;

import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "roles", catalog = "eduhack")
public class Roles extends SuperModel {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(min = 3, max = 20)
    @Column(name = "role", columnDefinition = "text COLLATE utf8mb4_unicode_ci", nullable = false)
    private String role;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "role_permissions", joinColumns = @JoinColumn(name = "role_id"), inverseJoinColumns = @JoinColumn(name = "permission_id"))
    private List<Permissions> permissions = new ArrayList<Permissions>();

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public List<Permissions> getPermissions() {
        return permissions;
    }
    public void setPermissions(List<Permissions> permissions) {
        this.permissions = permissions;
    }

}
