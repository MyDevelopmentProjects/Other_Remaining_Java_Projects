package ge.eduhack.model;

import com.sun.istack.internal.NotNull;
import ge.eduhack.mappedsupperclass.SuperModel;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
@Table(name = "user_rating", catalog = "eduhack")
public class UserRating extends SuperModel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "user1_id", nullable = false)
    private Users owner;

    @NotNull
    @ManyToOne(optional = false, fetch = FetchType.EAGER)
    @JoinColumn(name = "user2_id", nullable = false)
    private Users evaluator;

    @Min(1)
    @Max(10)
    @Column(name = "star_value", nullable = false)
    private Short starValue = 1;

    @Column(name = "comment", nullable = false, columnDefinition = "TEXT COLLATE utf8mb4_unicode_ci")
    private String comment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Users getOwner() {
        return owner;
    }

    public void setOwner(Users owner) {
        this.owner = owner;
    }

    public Users getEvaluator() {
        return evaluator;
    }

    public void setEvaluator(Users evaluator) {
        this.evaluator = evaluator;
    }

    public Short getStarValue() {
        return starValue;
    }

    public void setStarValue(Short starValue) {
        this.starValue = starValue;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}