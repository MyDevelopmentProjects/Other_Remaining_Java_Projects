package ge.eduhack.controller;

import ge.eduhack.model.Users;
import ge.eduhack.service.RegisterService;
import ge.eduhack.utils.RequestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/register")
public class RegisterController {

    @Autowired
    private RegisterService registerService;

    @RequestMapping("/choosePage")
    public String getChooser() {
        return "register/choose";
    }

    @RequestMapping("/trainer")
    public String getTrainerView() {
        return "register/trainer";
    }

    @RequestMapping("/organisation")
    public String getOrganisationView() {
        return "register/organisation";
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse saveUser(@RequestBody Users user) {
        Users u = registerService.saveUser(user);
        if (u == null) return RequestResponse.ERROR();
        else if (u.getId() == -1) return RequestResponse.createErrorResponse("USER_EXISTS", "", 0);
        return RequestResponse.SUCCESS();
    }

}
