package ge.eduhack.controller;

import ge.eduhack.dto.TrainingDTO;
import ge.eduhack.dto.TrainingShortDTO;
import ge.eduhack.dto.TrainingTrainerShortDTO;
import ge.eduhack.model.Training;
import ge.eduhack.model.TrainingTrainers;
import ge.eduhack.service.TrainingService;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/training")
public class TrainingController {

    @Autowired
    private TrainingService trainingService;

    @RequestMapping("/layout")
    public String getTrainingLayout() {
        return "training/training";
    }

    @RequestMapping("/adminLayout")
    public String getAdminTemplate() {
        return "security/training/training";
    }

    @RequestMapping("/innerLayout")
    public String getTrainingInnerLayout() {
        return "training/inner";
    }

    @PreAuthorize("hasAuthority('TRAINING_LIST')")
    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<TrainingDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize
    ) {
        return trainingService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    @PreAuthorize("hasAuthority('TRAINING_SAVE')")
    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse save(@RequestBody Training training) {
        trainingService.save(training);
        return RequestResponse.SUCCESS();
    }


    @PreAuthorize("hasAuthority('TRAINING_SAVE')")
    @RequestMapping(value = SLASH + "approve", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse approveTraining(@RequestBody Long id){
        trainingService.approveTraining(id);
        return RequestResponse.SUCCESS();
    }


    @RequestMapping(value = SLASH + "public" + SLASH + SAVE, method = RequestMethod.POST)
    @ResponseBody
    public Long savePublic(@RequestBody Training training) {
        Training saved = trainingService.saveForUser(training);
        return saved.getId() != null ? saved.getId() : 0L;
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse updateTraining(@RequestBody Training training) {
        boolean saved = trainingService.update(training);
        if (!saved) return RequestResponse.ERROR();
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = "/updateObjects", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse updateObjects(@RequestParam(value = "ids") String[] values, Long trainingId) {
        if (values != null &&
                values.length > 0 &&
                trainingId != null &&
                trainingId > 0) {
            trainingService.updateObjects(values, trainingId);
            return RequestResponse.SUCCESS();
        }
        return RequestResponse.ERROR();
    }

    @PreAuthorize("hasAuthority('TRAINING_DELETE')")
    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse delete(@RequestBody Long id) {
        trainingService.delete(id);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + "public" + SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<TrainingShortDTO> getPublicList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize,
            @RequestParam(required = false, defaultValue = "0") int categoryId,
            @RequestParam(required = false, defaultValue = "0") int cityId
    ) {
        return trainingService.getPublicList(searchExpression, sortField, isAscending, pageNumber, pageSize, categoryId, cityId);
    }

    @RequestMapping(value = "/{trainingId}", method = RequestMethod.GET)
    @ResponseBody
    public TrainingShortDTO getTrainingById(@PathVariable Long trainingId){
        Training training = trainingService.getTrainingById(trainingId);

        if(training == null){
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return mapper.convertValue(training, TrainingShortDTO.class);
    }

    @RequestMapping(value = SLASH + "training-trainer" + SLASH + LIST + SLASH +"{trainingId}", method = RequestMethod.GET)
    @ResponseBody
    public List<TrainingTrainerShortDTO> getOrganisationAndTrainerByTrainingId(@PathVariable Long trainingId){
        List<TrainingTrainers> training_trainers = trainingService.getOrganisationAndTrainerByTrainingId(trainingId);

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        List<TrainingTrainerShortDTO> training_trainer_list = new ArrayList<>();
        for(TrainingTrainers tag : training_trainers){
            training_trainer_list.add(mapper.convertValue(tag, TrainingTrainerShortDTO.class));
        }

        return training_trainer_list;
    }
}
