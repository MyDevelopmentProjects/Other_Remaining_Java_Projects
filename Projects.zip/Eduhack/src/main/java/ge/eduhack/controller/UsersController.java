package ge.eduhack.controller;

import ge.eduhack.config.exception.MGLException;
import ge.eduhack.dto.UserRatingShortDTO;
import ge.eduhack.dto.UserTagsWrapperDTO;
import ge.eduhack.dto.UsersDTO;
import ge.eduhack.dto.UsersUpdateDTO;
import ge.eduhack.model.Users;
import ge.eduhack.service.UsersService;
import ge.eduhack.utils.MGLUserUtils;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/user")
public class UsersController {

    @Autowired
    private UsersService usersService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "security/user/user";
    }

    @PreAuthorize("hasAuthority('USER_LIST')")
    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return usersService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    @PreAuthorize("hasAuthority('USER_SAVE')")
    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse saveUser(@RequestBody Users user) {
        usersService.saveUser(user);
        return RequestResponse.SUCCESS();
    }

    @PreAuthorize("hasAuthority('USER_DELETE')")
    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse deleteUser(@RequestBody Long id) throws MGLException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        usersService.deleteUser(id);
        return RequestResponse.SUCCESS();
    }

    @PreAuthorize("hasAuthority('Administrator') or hasAuthority('visitor')")
    @RequestMapping(value = SLASH + "editUserData", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse updateUserProfileData(@RequestBody Users user){
        return usersService.updateUserProfileData(MGLUserUtils.getCurrentUser().getId(), user);
    }

    @PreAuthorize("hasAuthority('Administrator') or hasAuthority('visitor')")
    @RequestMapping(value = SLASH + "update" + SLASH + "description", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse updateUserDescription(@RequestBody String description){
        return usersService.updateUserDescription(MGLUserUtils.getCurrentUser().getId(), description);
    }

    @PreAuthorize("hasAuthority('Administrator') or hasAuthority('visitor')")
    @RequestMapping(value = SLASH + "upload", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse saveUserUploadedImage(@RequestBody String imageURL){
        if(MGLUserUtils.getCurrentUser() == null){
            return RequestResponse.ERROR();
        }
        usersService.updateUserProfile(MGLUserUtils.getCurrentUser().getId(), imageURL);
        MGLUserUtils.getCurrentUser().setImgUrl(imageURL);
        return  RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + "tags", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UserTagsWrapperDTO> getUserTagList(
            @RequestParam(required = false, defaultValue = "0") int userId) {
        return usersService.getUserTagList(
                MGLUserUtils.isSuperAdmin() ? (userId != 0 ? userId:MGLUserUtils.getCurrentUser().getId()):MGLUserUtils.getCurrentUser().getId()
        );
    }

    @RequestMapping(value = SLASH + "rating", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UserRatingShortDTO> getUserRatingList(
            @RequestParam(required = false, defaultValue = "0") int userId) {
        return usersService.getUserRatingList(
                MGLUserUtils.isSuperAdmin() ? (userId != 0 ? userId:MGLUserUtils.getCurrentUser().getId()):MGLUserUtils.getCurrentUser().getId()
        );
    }

    @PreAuthorize("hasAuthority('Administrator') or hasAuthority('visitor')")
    @RequestMapping(value = SLASH + "self", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersUpdateDTO> getSelfUser(){
        if(!MGLUserUtils.isAuthenticated()) { return null; }

        Users user = MGLUserUtils.getCurrentUser();

        List<Users> listOfUsers = new ArrayList<>(1);
        listOfUsers.add(user);

        PaginationAndFullSearchQueryResult<Users> result = new PaginationAndFullSearchQueryResult<>();
        result.setCode(200);
        result.setMaxPages(1L);
        result.setSuccess(true);
        result.setTotal(1L);
        result.setResults(listOfUsers);

        return  result.transform(UsersUpdateDTO.class);
    }

    @PreAuthorize("hasAuthority('Administrator') or hasAuthority('visitor')")
    @RequestMapping(value = SLASH + "tag" + SLASH + "put", method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse setTag(@RequestBody Integer id){
        if(MGLUserUtils.getCurrentUser() == null){
            return RequestResponse.ERROR();
        }
        usersService.setUserTag(MGLUserUtils.getCurrentUser().getId(), id);
        return  RequestResponse.SUCCESS();
    }

}
