package ge.eduhack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class DefaultController {

    @RequestMapping("index")
    public String getMain() { return "default/main"; }

    @RequestMapping("about")
    public String getAbout() {
        return "default/about";
    }

    @RequestMapping("faq")
    public String getFaq() {
        return "default/faq";
    }

    @RequestMapping("rules")
    public String getRules() {
        return "default/rules";
    }

    @RequestMapping("profile")
    public String getProfile() { return "default/profile"; }

    @RequestMapping("profile/edit")
    public String editProfile() { return "default/profileEdit"; }

    @RequestMapping("profile/addTraining")
    public String addProfile() { return "default/profileAddTraining"; }

    @RequestMapping("security")
    public String getSecurity() {
        return "security/index";
    }

}
