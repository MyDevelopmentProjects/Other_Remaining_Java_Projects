package ge.eduhack.controller;

import ge.eduhack.dto.UserRatingShortDTO;
import ge.eduhack.dto.UserTagsShortDTO;
import ge.eduhack.dto.UserTrainerMapperDTO;
import ge.eduhack.dto.UsersShortDTO;
import ge.eduhack.model.UserRating;
import ge.eduhack.model.UserTags;
import ge.eduhack.model.Users;
import ge.eduhack.service.TrainingAndOrgService;
import ge.eduhack.service.UsersService;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/trainersAndOrganisations")
public class TrainerAndOrgController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private TrainingAndOrgService trainingAndOrgService;

    @RequestMapping("/trainerLayout")
    public String getTrainerLayout() {
        return "trainer/list";
    }

    @RequestMapping("/organisationLayout")
    public String getOrganisationLayout() {
        return "organisation/list";
    }

    @RequestMapping("/trainerInner")
    public String getTrainerInnerLayout() {
        return "trainer/inner";
    }

    @RequestMapping("/organisationInner")
    public String getOrganisationInnerLayout() {
        return "organisation/inner";
    }

    @RequestMapping(value = "/popularCompany", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersShortDTO> get3PopularCompanies(){
        return usersService.getPopulars(false);
    }

    @RequestMapping(value = "/popularTrainers", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersShortDTO> get3PopularTrainers(){
        return usersService.getPopulars(true);
    }

    @RequestMapping(value = "/trainer/{userId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String getTrainerById(@PathVariable Long userId){
        Users user = usersService.getUserByUserIdAndTrainerType(userId, true);
        List<UserTags> tags = usersService.getUserTagsLists(userId);
        List<UserRating> rating = usersService.getUserRatingLists(userId);

        if(user == null){
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        UsersShortDTO users = mapper.convertValue(user, UsersShortDTO.class);
        List<UserTagsShortDTO> user_tags = new ArrayList<>();
        for(UserTags tag : tags){
            user_tags.add(mapper.convertValue(tag, UserTagsShortDTO.class));
        }
        List<UserRatingShortDTO> user_rating = new ArrayList<>();
        for(UserRating rank : rating){
            user_rating.add(mapper.convertValue(rank, UserRatingShortDTO.class));
        }

        UserTrainerMapperDTO mappedClass = new UserTrainerMapperDTO();
        mappedClass.setUser(users);
        mappedClass.setTags(user_tags);
        mappedClass.setRating(user_rating);

        try {
            return mapper.writeValueAsString(mappedClass);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @RequestMapping(value = "/organisation/{userId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String getOrganisationById(@PathVariable Long userId){
        Users user = usersService.getUserByUserIdAndTrainerType(userId,false);
        List<UserTags> tags = usersService.getUserTagsLists(userId);

        if(user == null){
            return null;
        }

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        UsersShortDTO users = mapper.convertValue(user, UsersShortDTO.class);
        List<UserTagsShortDTO> user_tags = new ArrayList<>();
        for(UserTags tag : tags){
            user_tags.add(mapper.convertValue(tag, UserTagsShortDTO.class));
        }

        UserTrainerMapperDTO mappedClass = new UserTrainerMapperDTO();
        mappedClass.setUser(users);
        mappedClass.setTags(user_tags);

        try {
            return mapper.writeValueAsString(mappedClass);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @RequestMapping(value = "/statistics", method = RequestMethod.GET)
    @ResponseBody
    public String getStatistics(){
        long training = trainingAndOrgService.getTrainingCount();
        long trainer = trainingAndOrgService.getTrainerCount();
        long organisation = trainingAndOrgService.getOrganisationCount();

        Map<String, Long> statistics = new HashMap<>();
        statistics.put("training", training);
        statistics.put("trainer", trainer);
        statistics.put("organisation", organisation);

        ObjectMapper mapper = new ObjectMapper();

        try {
            return mapper.writeValueAsString(statistics);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


}
