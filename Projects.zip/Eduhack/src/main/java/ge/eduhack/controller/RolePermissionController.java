package ge.eduhack.controller;

import ge.eduhack.service.RolesService;
import ge.eduhack.utils.RequestResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;

@Controller
@RequestMapping("/rolepermission")
public class RolePermissionController {

    @Autowired
    private RolesService rolesService;

    @RequestMapping(SLASH + LAYOUT)
    public String getTemplate() {
        return "role/rolepermission";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('SHOW_ROLE_PERM')")
    @ResponseBody
    public List getList(@RequestParam(required = true, defaultValue = "0") long roleId) {
        return rolesService.getRolePermissions(roleId);
    }

    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @PreAuthorize("hasAuthority('ROLE_PERM_SAVE')")
    @ResponseBody
    public RequestResponse saveRole(@RequestBody String json) {
        rolesService.saveRolePermission(json);
        return RequestResponse.SUCCESS();
    }

}
