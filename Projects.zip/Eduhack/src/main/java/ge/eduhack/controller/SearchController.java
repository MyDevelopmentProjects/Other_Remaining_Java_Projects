package ge.eduhack.controller;

import ge.eduhack.dto.UsersShortDTO;
import ge.eduhack.service.UsersSearchService;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/search")
public class SearchController {

    @Autowired
    private UsersSearchService usersService;

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<UsersShortDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isTrainer,
            @RequestParam(required = false, defaultValue = "0") int starValue,
            @RequestParam(required = false, defaultValue = "0") int cityId
    ) {
        return usersService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize, isTrainer, starValue, cityId);
    }

}
