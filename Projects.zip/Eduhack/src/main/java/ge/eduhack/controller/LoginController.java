package ge.eduhack.controller;

import ge.eduhack.utils.constants.Constants.CustomCodeConstants;
import ge.eduhack.utils.constants.Constants.SuccessMessages;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

    @RequestMapping(value = {"/"}, method = RequestMethod.GET)
    public ModelAndView welcomePage() {
        ModelAndView model = new ModelAndView();
            model.setViewName("index");
        return model;
    }

    @RequestMapping("/forgotpwd")
    public String forgotPwd() {
        return "forgotpassword";
    }

    @RequestMapping("/register")
    public String register() {
        return "register";
    }

    @RequestMapping(value = CustomCodeConstants.SLASH + CustomCodeConstants.LOGIN, method = RequestMethod.GET)
    public ModelAndView login(String error, String logout) {
        ModelAndView model = new ModelAndView();
        if (error != null) {
            model.addObject(CustomCodeConstants.ERROR, "დაფიქსირდა შეცდომა");
            model.addObject(CustomCodeConstants.MSG, "1000");
        }
        if (logout != null) {
            model.addObject(CustomCodeConstants.MSG, SuccessMessages.LOGGED_OUT_SUCCESSFULLY);
        }
        model.setViewName(CustomCodeConstants.LOGIN);
        return model;
    }

}
