package ge.eduhack.controller;

import ge.eduhack.utils.MGLIOUtils;
import ge.eduhack.utils.MGLStringUtils;
import ge.eduhack.utils.MGLUploadHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
@RequestMapping("/upload")
public class UploadController {

    @RequestMapping(value = "/file", method = RequestMethod.POST)
    //@PreAuthorize("hasAuthority('UPLOAD_FILE')")
    @ResponseBody
    public List<String> uploadMultipleFileHandler(@RequestParam("file") MultipartFile[] files,
                                                  @RequestParam("type") String object
    ) {
        if (files == null || files.length == 0 ||
                MGLStringUtils.IsNullOrBlank(object)) return null;
        if (!MGLIOUtils.limitFileSize(files)) return null;
        if (!MGLIOUtils.isValidObjectPath(object)) return null;
        return MGLUploadHelper.uploadFiles(files, object);
    }
}
