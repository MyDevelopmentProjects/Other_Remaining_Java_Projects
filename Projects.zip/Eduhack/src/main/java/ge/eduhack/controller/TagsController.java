package ge.eduhack.controller;

import ge.eduhack.dto.TagsDTO;
import ge.eduhack.dto.TagsShortDTO;
import ge.eduhack.model.Tags;
import ge.eduhack.service.TagsService;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/tags")
public class TagsController {

    @Autowired
    private TagsService tagsService;

    @RequestMapping(SLASH + LAYOUT)
    public String getTemplate() {
        return "security/tags/tags";
    }

    @PreAuthorize("hasAuthority('TAG_LIST')")
    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<TagsDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return tagsService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    @PreAuthorize("hasAuthority('TAG_SAVE')")
    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse save(@RequestBody Tags tags) {
        tagsService.save(tags);
        return RequestResponse.SUCCESS();
    }

    @PreAuthorize("hasAuthority('TAG_DELETE')")
    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse delete(@RequestBody Long id) {
        tagsService.delete(id);
        return RequestResponse.SUCCESS();
    }

    @RequestMapping(value = SLASH + "public" + SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<TagsShortDTO> getPublicList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {

        return tagsService.getPublicList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

}
