package ge.eduhack.controller;

import ge.eduhack.dto.PermissionsDTO;
import ge.eduhack.service.PermissionsService;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/permission")
public class PermissionsController {

    @Autowired
    private PermissionsService permissionsService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "permission/permission";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('PERM_LIST')")
    @ResponseBody
    public PaginationAndFullSearchQueryResult<PermissionsDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize) {
        return permissionsService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

}
