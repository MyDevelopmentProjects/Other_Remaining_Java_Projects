package ge.eduhack.controller;

import ge.eduhack.dto.CategoriesDTO;
import ge.eduhack.model.Categories;
import ge.eduhack.service.CategoriesService;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.Keys.*;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.SLASH;
import static ge.eduhack.utils.constants.Constants.CustomCodeConstants.STRING_EMPTY;

@Controller
@RequestMapping("/category")
public class CategoriesController {

    @Autowired
    private CategoriesService categoryService;

    @RequestMapping("/layout")
    public String getTemplate() {
        return "security/category/category";
    }

    @RequestMapping(value = SLASH + LIST, method = RequestMethod.GET)
    @ResponseBody
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String searchExpression,
            @RequestParam(required = false, defaultValue = STRING_EMPTY) String sortField,
            @RequestParam(required = false, defaultValue = IS_ASCENDING_DEFAULT_VALUE) boolean isAscending,
            @RequestParam(value = PAGE_NUMBER, required = false, defaultValue = PAGE_NUMBER_DEFAULT_VALUE) Integer pageNumber,
            @RequestParam(required = false, defaultValue = PAGE_SIZE_DEFAULT_VALUE) int pageSize
            ) {
        return categoryService.getList(searchExpression, sortField, isAscending, pageNumber, pageSize);
    }

    @PreAuthorize("hasAuthority('CATEGORIES_SAVE')")
    @RequestMapping(value = SLASH + SAVE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse saveCategory(@RequestBody Categories category) {
        categoryService.saveCategory(category);
        return RequestResponse.SUCCESS();
    }

    @PreAuthorize("hasAuthority('CATEGORIES_DELETE')")
    @RequestMapping(value = SLASH + DELETE, method = RequestMethod.POST)
    @ResponseBody
    public RequestResponse deleteCategory(@RequestBody Long id) {
        categoryService.deleteCategory(id);
        return RequestResponse.SUCCESS();
    }

}
