package ge.eduhack.controller;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.HashMap;

/**
 * Created by vasho on 11.08.2016.
 */
@Controller
@RequestMapping("/errors")
public class ApplicationExceptionHandler {

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @RequestMapping("resourcenotfound")
    @ResponseBody
    public HashMap<String, String> resourceNotFound() throws Exception {
        HashMap<String, String> notFound = new HashMap(2);
        notFound.put("Error", "Resource Not Found");
        notFound.put("Code", "404");
        return notFound;
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @RequestMapping("unauthorised")
    @ResponseBody
    public HashMap<String, String> unAuthorised() throws Exception {
        HashMap<String, String> unauthorised = new HashMap(2);
        unauthorised.put("Error", "Unauthorised Request");
        unauthorised.put("Code", "401");
        return unauthorised;
    }

}