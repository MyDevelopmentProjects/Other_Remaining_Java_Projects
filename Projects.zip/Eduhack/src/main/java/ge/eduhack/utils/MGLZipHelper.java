package ge.eduhack.utils;

import java.io.*;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Created by Butqucha on 10/26/15.
 */
public class MGLZipHelper {

    /**
     * Given a File input it will unzip the file in a the unzip directory passed as the second parameter
     * @param inFile The zip file as input
     * @param unzipDir The unzip directory where to unzip the zip file.
     * @throws IOException
     */
    public static void unZip(File inFile,File unzipDir) throws IOException {
        Enumeration<? extends ZipEntry> entries;
        ZipFile zipFile=new ZipFile(inFile);
        try {
            entries=zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry=entries.nextElement();
                if (!entry.isDirectory()) {
                    InputStream in=zipFile.getInputStream(entry);
                    try {
                        File file=new File(unzipDir,entry.getName());
                        if (!file.getParentFile().mkdirs()) {
                            if (!file.getParentFile().isDirectory()) {
                                throw new IOException("Mkdirs failed to create " + file.getParentFile().toString());
                            }
                        }
                        OutputStream out=new FileOutputStream(file);
                        try {
                            byte[] buffer=new byte[8192];
                            int i;
                            while ((i=in.read(buffer)) != -1) {
                                out.write(buffer,0,i);
                            }
                        }
                        finally {
                            out.close();
                        }
                    }
                    finally {
                        in.close();
                    }
                }
            }
        }
        finally {
            zipFile.close();
        }
    }

}
