package ge.eduhack.utils;

import ge.eduhack.config.exception.MGLException;
import ge.eduhack.model.Users;

import java.lang.reflect.InvocationTargetException;

public class MGLDAORemovalManager<T> {
    public static <T> void canExecute(T model) throws MGLException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        java.lang.reflect.Method method;
        method = model.getClass().getMethod("getUsers");
        Users user = (Users) method.invoke(model);
        if (!user.getId().equals(MGLUserUtils.getCurrentUser().getId())) {
            throw new MGLException("Invalid record");
        }
    }
}
