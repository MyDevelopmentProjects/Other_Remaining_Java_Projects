package ge.eduhack.utils;

/**
 * Created by georgevashakidze on 8/28/16.
 */
public class MGLGRecaptchaHelper {

    public static final String url = "https://www.google.com/recaptcha/api/siteverify";
    public static final String secret = "6LfEtigTAAAAAEaG7rUpi4rPpvQrRf0ogvBaPUOT";
    private final static String USER_AGENT = "Mozilla/5.0";

    @SuppressWarnings("unchecked")
    public static boolean verify(String gRecaptchaResponse) {

        return true;

        /*if (MGLStringUtils.IsNullOrBlank(gRecaptchaResponse)) {
            return false;
        }

        try {
            URL obj = new URL(url);
            HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

            con.setRequestMethod("POST");
            con.setRequestProperty("User-Agent", USER_AGENT);
            con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

            String postParams = "secret=" + secret + "&response="
                    + gRecaptchaResponse;

            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(postParams);
            wr.flush();
            wr.close();

            int responseCode = con.getResponseCode();
            System.out.println("\nSending 'POST' request to URL : " + url);
            System.out.println("Post parameters : " + postParams);
            System.out.println("Response Code : " + responseCode);

            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //parse JSON response and return 'success' value
            ObjectMapper objectMapper = new ObjectMapper();

            HashMap<String, Object> result = (HashMap<String, Object>) objectMapper.readValue(response.toString(), HashMap.class);

            return (Boolean) result.getOrDefault("success", false);

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }*/
    }
}