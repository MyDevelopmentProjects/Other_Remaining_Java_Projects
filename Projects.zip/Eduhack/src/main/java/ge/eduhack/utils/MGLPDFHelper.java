package ge.eduhack.utils;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;
import ge.eduhack.utils.constants.Constants;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class MGLPDFHelper {
    public static String generatePDF(String rootPath) throws DocumentException, IOException {
        Document document = new Document();
        String md5String = MGLMainUtils.MD5(MGLMainUtils.generateString(11));
        String ap = MGLIOUtils.checkDirs(Constants.UploadHelpers.INVOICE_PDF);
        String pdfFilePath = MGLIOUtils.checkDirs(ap);
        String pdf = String.format("%s%s%s%s", pdfFilePath, File.separator, md5String, ".pdf");
        PdfWriter.getInstance(document, new FileOutputStream(pdf));
        document.open();
        Image img = Image.getInstance(rootPath);

        float documentWidth = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
        float documentHeight = document.getPageSize().getHeight() - document.topMargin() - document.bottomMargin();
        img.scaleToFit(documentWidth, documentHeight);

        document.add(img);
        document.close();
        return pdf;
    }
}