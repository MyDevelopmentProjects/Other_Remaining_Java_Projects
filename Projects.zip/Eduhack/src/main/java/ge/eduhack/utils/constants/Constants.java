package ge.eduhack.utils.constants;

import java.io.File;

public class Constants {

    public static final String[] VALID_EXTENSIONS = {"png", "jpg", "pdf", "xls", "xlsx", "doc", "docx"};
    public static final String[] VALID_OBJECT_NAMES = { "TRAINING", "USERS" };

    public static final class UploadHelpers {
        private static final String HOME = String.format("%s%s", System.getProperty("user.home"), File.separator);
        private static final String UPLOADS = String.format("%s%s%s", HOME, "uploads", File.separator);
        public static final String INVOICE_PDF = String.format("%s%s", UPLOADS, "invoice_pdf");
        public static final String USERS_PATH = String.format("%s%s", UPLOADS, "users");
        public static final String TRAINING_PATH = String.format("%s%s", UPLOADS, "training");
        public static final String DEFAULT_PATH = String.format("%s%s", UPLOADS, "default");

    }

    /**
     * Error Code Constants.
     * Starting from 1000 till 2000
     */
    public static final class ErrorCodes {

        public class ErrorResponse {
            public static final String ACCESS_IS_DENIED = "access_is_denied";
            public static final String UNKNOWN = "unknown";
            public static final String DUPLICATE_RECORD = "DUPLICATE_RECORD";
            public static final String RECORD_IS_USED_IN_OTHER_TABLES = "RECORD_IS_USED_IN_OTHER_TABLES";
            public static final String PERSISTENCE_EXCEPTION = "javax.persistence.PersistenceException";
            public static final String NO_ENOUGH_MONEY = "NO_ENOUGH_MONEY";
            public static final String NO_ENOUGH_MINUTES = "NO_ENOUGH_MINUTES";
            public static final String NO_ENOUGH_SMS = "NO_ENOUGH_SMS";
            public static final String SMS_USER_NOT_YET_REGISTERED = "SMS_USER_NOT_YET_REGISTERED";
            public static final String SALARY_IS_ALREADY_CREATED_FOR_TODAY = "SALARY_IS_ALREADY_CREATED_FOR_TODAY";
        }

        public class ErrorMessages {
            public static final String TRIAL_DATE_HAS_BEEN_EXPIRED = "საცდელი ვადა გასულია. დაუკავშირდით ადმინისტრაციას";
            public static final String INCORRECT_CREDS = "არასწორი მომხმარებელი ან პაროლი";
            public static final String USER_NOT_FOUND = "მომხმარებელი ვერ მოიძებნა";
        }

    }

    /**
     * SuccessMessages Code Constants.
     * Starting from 2000 till 3000
     */
    public static final class SuccessMessages {
        public static final int LOGGED_OUT_SUCCESSFULLY = 3000;
        public static final int OPERATION_COMPLETED_SUCCESSFULLY = 3001;
    }

    /**
     * CustomCodeConstants code Constants
     * This class contains all the string constants, needed in the classes while coding something
     */
    public static final class CustomCodeConstants {

        public static final String ERROR = "error";
        public static final String LOGOUT = "logout";
        public static final String LOGIN = "login";
        public static final String REDIRECT_TO_MAIN = "redirect:/";
        public static final String INDEX = "index";
        public static final String SLASH = "/";
        public static final String MSG = "msg";
        public static final String SUCCESS = "success";
        public static final String CODE = "code";
        public static final String SOURCE = "source";
        public static final String MESSAGE = "message";
        public static final String RESOURCES_ALL = "/resources/**";
        public static final String DEFAULT_PERMISSIONS = "/resources/serverResources/permissions/defaultPermissions.query";
        public static final String STRING_EMPTY = "";
        public static final String UNKNOWN_ERROR = "Something went wrong!";
        public static final String SITE_ID = "siteId";


        public static class Keys {

            public static final String PAGE_NUMBER = "pageNumber";
            public static final String PAGE_NUMBER_DEFAULT_VALUE = "0";
            public static final String PAGE_SIZE_DEFAULT_VALUE = "10";
            public static final String IS_ASCENDING_DEFAULT_VALUE = "true";
            public static final String LIST = "list";
            public static final String APP = "application";
            public static final String LAYOUT = "layout";
            public static final String SAVE = "save";
            public static final String DELETE = "delete";
            public static final String ROLE_ID = "RoleId";
            public static final String PERMISSIONS = "Permissions";
            public static final String KEY = "key";
            public static final String VALUE = "value";


        }
    }


}
