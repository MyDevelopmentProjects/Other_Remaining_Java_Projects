package ge.eduhack.utils;

import ge.eduhack.model.Users;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;

public class MGLUserUtils {

    private static Authentication getCurrentLoggedInUser() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    public static boolean isAuthenticated() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return auth != null &&
                auth.isAuthenticated() &&
                !(auth instanceof AnonymousAuthenticationToken);
    }

    public static Users getCurrentUser() {
        return (Users) getCurrentLoggedInUser().getPrincipal();
    }

    private static Collection<? extends GrantedAuthority> getCurrentUserAuthorities() {
        return getCurrentLoggedInUser().getAuthorities();
    }

    public static boolean hasAuthority(String authority) {
        for (GrantedAuthority auth : getCurrentUserAuthorities()) {
            if (auth.getAuthority().equals(authority)) {
                return true;
            }
        }
        return false;
    }

    public static void refreshAuthorisedUser(Users updatedUserObject){
        if(isAuthenticated()){
            Authentication authentication = new UsernamePasswordAuthenticationToken(updatedUserObject, null, getCurrentUserAuthorities());
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }
    }

    public static boolean isSuperAdmin() {
        return getCurrentUser().isSuperAdmin();
    }
}
