package ge.eduhack.utils;

import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import static ge.eduhack.utils.constants.Constants.UploadHelpers.*;

/**
 * Created by Butqucha on 10/26/15.
 */
public class MGLUploadHelper {

    public static List<String> uploadFiles(MultipartFile[] files, String objectName) {
        List<String> fileNames = new ArrayList<>(files.length);
        for (int i = 0; i < files.length; i++) {
            String uploadPath = getPath(objectName);
            MultipartFile file = files[i];
            try {
                String extension;
                int index = file.getOriginalFilename().lastIndexOf('.');
                if (index >= 0) {
                    extension = file.getOriginalFilename().substring(index + 1);
                }
                else continue;
                if (!MGLIOUtils.isValidExtension(extension.toLowerCase())) {
                    continue;
                }
                byte[] bytes = file.getBytes();
                uploadPath = String.format("%s%s", uploadPath, File.separator);
                String ap = MGLIOUtils.checkDirs(uploadPath);
                String md5String = MGLMainUtils.MD5(MGLMainUtils.generateString(11));
                String md5FileName = String.format("%s%s%s", md5String, ".", extension);
                String serverFileName = String.format("%s%s%s", ap, File.separator, md5FileName);
                File serverFile = new File(serverFileName);
                BufferedOutputStream stream = new BufferedOutputStream( new FileOutputStream(serverFile));
                stream.write(bytes);
                stream.close();

                String returnPath = makeThumbs(extension, serverFileName);
                if (!MGLStringUtils.IsNullOrBlank(returnPath))
                    md5FileName = returnPath;
                fileNames.add(md5FileName);
            } catch (Exception e) {
            }
        }
        return fileNames;
    }

    private static String makeThumbs(String extension, String path) {
        if (extension.equals("png") || extension.equals("jpg")) {
            return MGLIOUtils.ImageUtils.resizeImage(path);
        }
        return "";
    }

    private static String getPath(String path) {
        switch (path) {
            case "TRAINING":
                return TRAINING_PATH;
            case "USERS":
                return USERS_PATH;
            default:
                return DEFAULT_PATH;
        }
    }
}
