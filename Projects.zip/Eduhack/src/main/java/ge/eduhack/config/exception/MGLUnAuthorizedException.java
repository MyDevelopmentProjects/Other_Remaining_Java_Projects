package ge.eduhack.config.exception;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;

@Component
public class MGLUnAuthorizedException implements AuthenticationEntryPoint {
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
            throws IOException, ServletException {
        HashMap<String, String> map = new HashMap<>(3);
        map.put("Error","AUTHENTICATION_IS_REQUIRED");
        map.put("Message","UnAuthorized");
        map.put("Code","10001");
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonInString = objectMapper.writeValueAsString(map);
        response.setStatus(401);
        response.getWriter().print(jsonInString);
        response.setHeader("Content-Type", "application/json");
        response.getWriter().flush();
    }
}
