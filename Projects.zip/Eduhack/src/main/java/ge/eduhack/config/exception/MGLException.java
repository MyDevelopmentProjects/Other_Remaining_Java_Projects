package ge.eduhack.config.exception;

/**
 * Created by vasho on 16.04.2016.
 */
public class MGLException extends Exception {

    private String message;

    public MGLException(String message) {
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }

}
