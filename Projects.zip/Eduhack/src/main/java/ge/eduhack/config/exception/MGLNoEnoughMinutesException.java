package ge.eduhack.config.exception;

public class MGLNoEnoughMinutesException extends MGLException {

    public MGLNoEnoughMinutesException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

}
