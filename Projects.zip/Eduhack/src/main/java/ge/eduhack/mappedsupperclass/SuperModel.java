package ge.eduhack.mappedsupperclass;

import ge.eduhack.utils.MGLUserUtils;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Vasho on 7/28/15.
 */



@MappedSuperclass
public abstract class SuperModel {

    @Column(name = "dateCreated", nullable = false, columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", insertable = false, updatable = false)
    public Date dateCreated;

    @Column(name = "dateUpdated", nullable = true, columnDefinition = "TIMESTAMP NULL")
    public Date dateUpdated;

    @Column(name = "dateDeleted", nullable = true, columnDefinition = "TIMESTAMP NULL")
    public Date dateDeleted;

    @Column(name = "meta", columnDefinition = "text COLLATE utf8mb4_unicode_ci", nullable = true)
    private String meta;

    @Column(name = "creator_id")
    private Long creatorId;

    @PrePersist
    void onCreate() {
        this.setDateCreated(new Timestamp((new Date()).getTime()));
        this.setCreatorId(MGLUserUtils.getCurrentUser().getId());
    }
    @PreUpdate
    void onPersist() {
        this.setDateUpdated(new Timestamp((new Date()).getTime()));
    }
    @PreRemove
    void onRemove() {
        this.setDateDeleted(new Timestamp((new Date()).getTime()));
    }

    public Date getDateCreated() {
        return dateCreated;
    }
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }
    public Date getDateUpdated() {
        return dateUpdated;
    }
    public void setDateUpdated(Date dateUpdated) {
        this.dateUpdated = dateUpdated;
    }
    public Date getDateDeleted() {
        return dateDeleted;
    }
    public void setDateDeleted(Date dateDeleted) {
        this.dateDeleted = dateDeleted;
    }
    public String getMeta() {
        return meta;
    }
    public void setMeta(String meta) {
        this.meta = meta;
    }
    public Long getCreatorId() {
        return creatorId;
    }
    public void setCreatorId(Long creatorId) {
        this.creatorId = creatorId;
    }
}
