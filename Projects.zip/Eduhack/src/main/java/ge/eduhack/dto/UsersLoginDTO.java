package ge.eduhack.dto;

import ge.eduhack.mappedsupperclass.SuperDTO;

import java.util.Date;

public class UsersLoginDTO extends SuperDTO  {

    private Long id;
    private RolesDTO role;
    private String name;
    private String title;
    private String description;
    private String userName;
    private String password;
    private String firstName;
    private String lastName;
    private String firstAndLast;
    private String email;
    private Date dob;
    private String mNumber;
    private String webPage;
    private String location;
    private CitiesDTO city;
    private Short starValue = 0;
    private String imgUrl;
    private String address;
    private boolean gender = false;
    private boolean active = false;
    private boolean trainer = false;
    private boolean superAdmin = false;
    private String gRecaptchaKey;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public RolesDTO getRole() {
        return role;
    }

    public void setRole(RolesDTO role) {
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstAndLast() {
        return firstAndLast;
    }

    public void setFirstAndLast(String firstAndLast) {
        this.firstAndLast = firstAndLast;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getmNumber() {
        return mNumber;
    }

    public void setmNumber(String mNumber) {
        this.mNumber = mNumber;
    }

    public String getWebPage() {
        return webPage;
    }

    public void setWebPage(String webPage) {
        this.webPage = webPage;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public CitiesDTO getCity() {
        return city;
    }

    public void setCity(CitiesDTO city) {
        this.city = city;
    }

    public Short getStarValue() {
        return starValue;
    }

    public void setStarValue(Short starValue) {
        this.starValue = starValue;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isTrainer() {
        return trainer;
    }

    public void setTrainer(boolean trainer) {
        this.trainer = trainer;
    }

    public boolean isSuperAdmin() {
        return superAdmin;
    }

    public void setSuperAdmin(boolean superAdmin) {
        this.superAdmin = superAdmin;
    }

    public String getgRecaptchaKey() {
        return gRecaptchaKey;
    }

    public void setgRecaptchaKey(String gRecaptchaKey) {
        this.gRecaptchaKey = gRecaptchaKey;
    }
}
