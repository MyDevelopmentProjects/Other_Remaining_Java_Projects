package ge.eduhack.dto;

/**
 * Created by Mikha on 9/12/2016.
 */
public class UserRatingShortDTO {
    private Long id;
    private UsersShortDTO evaluator;
    private Short starValue = 1;
    private String comment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UsersShortDTO getEvaluator() {
        return evaluator;
    }

    public void setEvaluator(UsersShortDTO evaluator) {
        this.evaluator = evaluator;
    }

    public Short getStarValue() {
        return starValue;
    }

    public void setStarValue(Short starValue) {
        this.starValue = starValue;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
