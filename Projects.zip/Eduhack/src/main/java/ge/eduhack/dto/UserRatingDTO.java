package ge.eduhack.dto;

import ge.eduhack.mappedsupperclass.SuperDTO;

public class UserRatingDTO extends SuperDTO {

    private Long id;
    private UsersDTO owner;
    private UsersDTO evaluator;
    private Short starValue = 1;
    private String comment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UsersDTO getOwner() {
        return owner;
    }

    public void setOwner(UsersDTO owner) {
        this.owner = owner;
    }

    public UsersDTO getEvaluator() {
        return evaluator;
    }

    public void setEvaluator(UsersDTO evaluator) {
        this.evaluator = evaluator;
    }

    public Short getStarValue() {
        return starValue;
    }

    public void setStarValue(Short starValue) {
        this.starValue = starValue;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
