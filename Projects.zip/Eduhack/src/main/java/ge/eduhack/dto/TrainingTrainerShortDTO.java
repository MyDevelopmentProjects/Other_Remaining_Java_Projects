package ge.eduhack.dto;

/**
 * Created by Mikha on 9/28/2016.
 */
public class TrainingTrainerShortDTO {

    private UsersShortDTO trainingObject;

    public UsersShortDTO getTrainingObject() {
        return trainingObject;
    }
    public void setTrainingObject(UsersShortDTO trainingObject) {
        this.trainingObject = trainingObject;
    }
}
