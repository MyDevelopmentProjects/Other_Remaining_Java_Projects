package ge.eduhack.dto;

/**
 * Created by Mikha on 9/28/2016.
 */
public class UserTagsShortDTO {

    private TagsShortDTO tag;

    public TagsShortDTO getTag() {
        return tag;
    }
    public void setTag(TagsShortDTO tag) {
        this.tag = tag;
    }
}
