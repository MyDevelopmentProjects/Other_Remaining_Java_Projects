package ge.eduhack.dto;

import ge.eduhack.mappedsupperclass.SuperDTO;

public class UserTagsDTO extends SuperDTO {

    private UsersDTO user;
    private TagsDTO tag;

    public UsersDTO getUser() {
        return user;
    }
    public void setUser(UsersDTO user) {
        this.user = user;
    }
    public TagsDTO getTag() {
        return tag;
    }
    public void setTag(TagsDTO tag) {
        this.tag = tag;
    }

}
