package ge.eduhack.dto;

import ge.eduhack.mappedsupperclass.SuperDTO;

public class TrainingTrainersDTO extends SuperDTO {

    private  Long id;
    private TrainingDTO training;
    private UsersDTO trainingObject;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TrainingDTO getTraining() {
        return training;
    }
    public void setTraining(TrainingDTO training) {
        this.training = training;
    }

    public UsersDTO getTrainingObject() {
        return trainingObject;
    }

    public void setTrainingObject(UsersDTO trainingObject) {
        this.trainingObject = trainingObject;
    }
}
