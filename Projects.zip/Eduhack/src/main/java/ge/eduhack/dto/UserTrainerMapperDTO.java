package ge.eduhack.dto;

import java.util.List;

/**
 * Created by Mikha on 9/15/2016.
 */
public class UserTrainerMapperDTO {

    private UsersShortDTO user;
    private List<UserTagsShortDTO> tags;
    private List<UserRatingShortDTO> rating;

    public UsersShortDTO getUser() {
        return user;
    }

    public void setUser(UsersShortDTO user) {
        this.user = user;
    }

    public List<UserTagsShortDTO> getTags() {
        return tags;
    }

    public void setTags(List<UserTagsShortDTO> tags) {
        this.tags = tags;
    }

    public List<UserRatingShortDTO> getRating() {
        return rating;
    }

    public void setRating(List<UserRatingShortDTO> rating) {
        this.rating = rating;
    }
}
