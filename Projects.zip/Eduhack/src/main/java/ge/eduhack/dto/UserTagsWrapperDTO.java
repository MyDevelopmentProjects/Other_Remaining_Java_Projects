package ge.eduhack.dto;

public class UserTagsWrapperDTO {

    private TagsDTO tag;

    public TagsDTO getTag() {
        return tag;
    }

    public void setTag(TagsDTO tag) {
        this.tag = tag;
    }
}
