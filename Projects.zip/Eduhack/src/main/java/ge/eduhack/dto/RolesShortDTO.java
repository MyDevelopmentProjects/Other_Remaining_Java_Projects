package ge.eduhack.dto;

/**
 * Created by Mikha on 9/21/2016.
 */
public class RolesShortDTO {
    private Long id;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
}
