package ge.eduhack.dto;

import java.util.Date;

/**
 * Created by Mikha on 9/21/2016.
 */
public class TrainingShortDTO {

    private Long id;
    private String name;
    private UsersShortDTO createdBy;
    private CitiesDTO city;
    private CategoriesShortDTO category;
    private Date dateFrom;
    private Date dateTo;
    private Double price;
    private String shortDescription;
    private String deepDescription;
    private String imgUrl;
    private boolean payable = false;
    private boolean approved = false;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public UsersShortDTO getCreatedBy() {
        return createdBy;
    }
    public void setCreatedBy(UsersShortDTO createdBy) {
        this.createdBy = createdBy;
    }
    public CitiesDTO getCity() {
        return city;
    }
    public void setCity(CitiesDTO city) {
        this.city = city;
    }
    public CategoriesShortDTO getCategory() {
        return category;
    }
    public void setCategory(CategoriesShortDTO category) {
        this.category = category;
    }
    public Date getDateFrom() {
        return dateFrom;
    }
    public void setDateFrom(Date dateFrom) {
        this.dateFrom = dateFrom;
    }
    public Date getDateTo() {
        return dateTo;
    }
    public void setDateTo(Date dateTo) {
        this.dateTo = dateTo;
    }
    public Double getPrice() {
        return price;
    }
    public void setPrice(Double price) {
        this.price = price;
    }
    public String getShortDescription() {
        return shortDescription;
    }
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }
    public String getDeepDescription() {
        return deepDescription;
    }
    public void setDeepDescription(String deepDescription) {
        this.deepDescription = deepDescription;
    }
    public String getImgUrl() {
        return imgUrl;
    }
    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }
    public boolean isPayable() {
        return payable;
    }
    public void setPayable(boolean payable) {
        this.payable = payable;
    }
    public boolean isApproved() {
        return approved;
    }
    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}