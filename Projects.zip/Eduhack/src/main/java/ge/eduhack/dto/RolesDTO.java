package ge.eduhack.dto;

import ge.eduhack.mappedsupperclass.SuperDTO;

public class RolesDTO extends SuperDTO  {

    private Long id;
    private String role;

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }

}
