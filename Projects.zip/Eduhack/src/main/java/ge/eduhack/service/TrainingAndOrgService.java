package ge.eduhack.service;

import ge.eduhack.dao.TrainingAndOrgDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Mikha on 9/20/2016.
 */
@Service
public class TrainingAndOrgService {

    @Autowired
    private TrainingAndOrgDAO trainingAndOrgDAO;

    public long getTrainingCount(){
        return trainingAndOrgDAO.getTrainingCount();
    }

    public long getTrainerCount(){
        return trainingAndOrgDAO.getTrainerOrOrganisationCount(true);
    }

    public long getOrganisationCount(){
        return trainingAndOrgDAO.getTrainerOrOrganisationCount(false);
    }

}
