package ge.eduhack.service;

import ge.eduhack.dao.UsersDAO;
import ge.eduhack.model.Roles;
import ge.eduhack.model.Users;
import ge.eduhack.utils.MGLGRecaptchaHelper;
import ge.eduhack.utils.MGLStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegisterService {

    @Autowired
    private UsersDAO usersDAO;

    private boolean validateOrganisation(Users user) {

        String[] items = {
                user.getUserName(),
                user.getPassword(),
                user.getName(),
                user.getEmail(),
                user.getWebPage(),
                user.getmNumber(),
                user.getAddress()
        };

        return !MGLStringUtils.IsNullOrBlank(items) &&
                user.getCity() != null &&
                user.getCity().getId() != null;

    }

    private boolean validateTrainer(Users user) {

        String[] items = {
                user.getUserName(),
                user.getPassword(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getmNumber()
        };

        return !MGLStringUtils.IsNullOrBlank(items) &&
                user.getCity() != null && user.getCity().getId() != null &&
                user.getDob() != null;

    }

    private boolean validate(Users user) {

        boolean isValid;

        if (user.isTrainer()) isValid = this.validateTrainer(user);

        else isValid = this.validateOrganisation(user);

        return isValid;

    }

    @Transactional
    public Users saveUser(Users user) {

        user.setId(null);


        if (!validate(user)) {
            return null;
        }

        if (!MGLGRecaptchaHelper.verify(user.getgRecaptchaKey())) return null;

        if (usersDAO.checkIfUserExists(user.getUserName())) {
            Users u = new Users();
            u.setId(-1L);
            return u;
        }

        user.setSuperAdmin(false);
        user.setActive(false);

        Roles role = new Roles();
        role.setId(2L);
        user.setRole(role);

        return usersDAO.saveUser(user);

    }

}
