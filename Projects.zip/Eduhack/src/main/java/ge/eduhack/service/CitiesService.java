package ge.eduhack.service;

import ge.eduhack.dao.CitiesDAO;
import ge.eduhack.dto.CitiesDTO;
import ge.eduhack.model.Cities;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CitiesService {

    @Autowired
    private CitiesDAO citiesDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CitiesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return citiesDAO.getPaginatedResultList(Cities.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(CitiesDTO.class);
    }

    @Transactional
    public Cities save(Cities cities) {
        return citiesDAO.save(cities);
    }

    @Transactional
    public boolean delete(Long id) {
        citiesDAO.delete(id);
        return true;
    }

}
