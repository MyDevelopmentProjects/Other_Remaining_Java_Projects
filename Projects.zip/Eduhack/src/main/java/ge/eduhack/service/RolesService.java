package ge.eduhack.service;

import ge.eduhack.dao.RolesDAO;
import ge.eduhack.dto.RolesDTO;
import ge.eduhack.model.Roles;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RolesService {

    @Autowired
    private RolesDAO rolesDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<RolesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return rolesDAO.getPaginatedResultList(Roles.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(RolesDTO.class);
    }

    @Transactional(readOnly = true)
    public List getRolePermissions(long roleId) {
        return rolesDAO.getRolePermissionsByRoleId(roleId);
    }

    @Transactional
    public boolean saveRolePermission(String json) {
        rolesDAO.saveRolePermission(json);
        return true;
    }

    @Transactional
    public void saveListOfRolePermissions(String query) {
        rolesDAO.saveListOfRolePermission(query);
    }

    @Transactional
    public Roles saveRole(Roles role) {
        return rolesDAO.saveRole(role);
    }

    @Transactional
    public boolean deleteRole(Long id) {
        rolesDAO.deleteRole(id);
        return true;
    }

}
