package ge.eduhack.service;

import ge.eduhack.dao.UsersSearchDAO;
import ge.eduhack.dto.UsersShortDTO;
import ge.eduhack.model.Users;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UsersSearchService {

    @Autowired
    private UsersSearchDAO usersSearchDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<UsersShortDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize,
                                                                     boolean isTrainer, int starValue, int cityId) {
        return usersSearchDAO.getPaginatedResultList(Users.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, isTrainer, starValue, cityId).transform(UsersShortDTO.class);
    }
}