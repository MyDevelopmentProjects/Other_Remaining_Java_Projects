package ge.eduhack.service;

import ge.eduhack.dao.PermissionsDAO;
import ge.eduhack.dto.PermissionsDTO;
import ge.eduhack.model.Permissions;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PermissionsService {

    @Autowired
    private PermissionsDAO permissionsDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<PermissionsDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return permissionsDAO.getPaginatedResultList(Permissions.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(PermissionsDTO.class);
    }

}
