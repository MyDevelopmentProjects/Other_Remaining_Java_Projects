package ge.eduhack.service;

import ge.eduhack.dao.CategoriesDAO;
import ge.eduhack.dto.CategoriesDTO;
import ge.eduhack.model.Categories;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CategoriesService {

    @Autowired
    private CategoriesDAO categoryDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<CategoriesDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return categoryDAO.getPaginatedResultList(Categories.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(CategoriesDTO.class);
    }

    @Transactional
    public Categories saveCategory(Categories categories) {
        return categoryDAO.saveCategory(categories);
    }

    @Transactional
    public void deleteCategory(Long id) {
        categoryDAO.deleteCategory(id);
    }

}
