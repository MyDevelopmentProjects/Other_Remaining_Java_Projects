package ge.eduhack.service;

import ge.eduhack.dao.TagsDAO;
import ge.eduhack.dto.TagsDTO;
import ge.eduhack.dto.TagsShortDTO;
import ge.eduhack.model.Tags;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TagsService {

    @Autowired
    private TagsDAO tagsDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TagsDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return tagsDAO.getPaginatedResultList(Tags.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(TagsDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TagsShortDTO> getPublicList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return tagsDAO.getPaginatedResultList(Tags.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(TagsShortDTO.class);
    }

    @Transactional
    public Tags save(Tags Tags) {
        return tagsDAO.save(Tags);
    }

    @Transactional
    public boolean delete(Long id) {
        tagsDAO.delete(id);
        return true;
    }

}
