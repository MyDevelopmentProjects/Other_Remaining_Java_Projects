package ge.eduhack.service;

import ge.eduhack.dao.TrainingDAO;
import ge.eduhack.dto.TrainingDTO;
import ge.eduhack.dto.TrainingShortDTO;
import ge.eduhack.model.Training;
import ge.eduhack.model.TrainingTrainers;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class TrainingService {

    @Autowired
    private TrainingDAO trainingDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TrainingDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return trainingDAO.getPaginatedResultList(Training.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(TrainingDTO.class);
    }

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TrainingShortDTO> getPublicList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize, long category, long city) {
        return trainingDAO.getPaginatedResultList(Training.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize,category,city).transform(TrainingShortDTO.class);
    }

    @Transactional
    public Training save(Training training) {
        return trainingDAO.save(training, false);
    }

    @Transactional
    public Training saveForUser(Training training) {
        return trainingDAO.save(training, true);
    }

    @Transactional
    public void approveTraining(Long id){
        trainingDAO.approveTraining(id);
    }

    @Transactional
    public void delete(Long id) {
        trainingDAO.delete(id);
    }

    @Transactional
    public boolean update(Training training) {
        return trainingDAO.update(training);
    }

    @Transactional
    public void updateObjects(String[] values, Long trainingId) {
        trainingDAO.updateObjects(values, trainingId);
    }

    @Transactional
    public Training getTrainingById(long trainingId){
        return trainingDAO.getTrainingById(trainingId);
    }

    @Transactional
    public List<TrainingTrainers> getOrganisationAndTrainerByTrainingId(long trainingId){
        return trainingDAO.getOrganisationAndTrainerByTrainingId(trainingId);
    }
}
