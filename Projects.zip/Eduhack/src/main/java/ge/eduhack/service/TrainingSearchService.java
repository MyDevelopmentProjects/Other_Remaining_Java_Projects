package ge.eduhack.service;

import ge.eduhack.dao.TrainingSearchDAO;
import ge.eduhack.dto.TrainingDTO;
import ge.eduhack.model.Users;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TrainingSearchService {

    @Autowired
    private TrainingSearchDAO trainingSearchDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<TrainingDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize,
                                                                   String name, Long categoryId, Long cityId) {
        return trainingSearchDAO.getPaginatedResultList(Users.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize, name, categoryId, cityId).transform(TrainingDTO.class);
    }

}
