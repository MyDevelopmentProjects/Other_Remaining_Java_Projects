package ge.eduhack.service;

import ge.eduhack.config.exception.MGLException;
import ge.eduhack.dao.UsersDAO;
import ge.eduhack.dto.UserRatingShortDTO;
import ge.eduhack.dto.UserTagsWrapperDTO;
import ge.eduhack.dto.UsersDTO;
import ge.eduhack.dto.UsersShortDTO;
import ge.eduhack.model.UserRating;
import ge.eduhack.model.UserTags;
import ge.eduhack.model.Users;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

@Service
public class UsersService {

    @Autowired
    private UsersDAO usersDAO;

    @Transactional(readOnly = true)
    public PaginationAndFullSearchQueryResult<UsersDTO> getList(String searchExpression, String sortField, boolean isAscending, Integer pageNumber, int pageSize) {
        return usersDAO.getPaginatedResultList(Users.class, searchExpression,
                sortField, isAscending, pageNumber, pageSize).transform(UsersDTO.class);
    }

    @Transactional
    public Users checkIfUserExists(String username, String password) {
        return usersDAO.checkIfUserExists(username, password);
    }

    @Transactional
    public Users saveUser(Users user) {
        return usersDAO.saveUser(user);
    }

    @Transactional
    public void deleteUser(Long id) throws MGLException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        usersDAO.deleteUser(id);
    }

    public PaginationAndFullSearchQueryResult<UsersShortDTO> getPopulars(boolean isTrainer) {
        List<Users> listOfUsers = usersDAO.getPopulars(isTrainer);
        PaginationAndFullSearchQueryResult<Users> result = new PaginationAndFullSearchQueryResult<>();
        result.setSuccess(true);
        result.setCode(200);
        result.setTotal(3L);
        result.setMaxPages(1L);
        result.setResults(listOfUsers);
        return result.transform(UsersShortDTO.class);
    }

    public PaginationAndFullSearchQueryResult<UserTagsWrapperDTO> getUserTagList(long userId) {
        List<UserTags> listOfUsers = usersDAO.getUserTagByUserId(userId);

        PaginationAndFullSearchQueryResult<UserTags> result = new PaginationAndFullSearchQueryResult<>();
        result.setSuccess(true);
        result.setCode(200);
        result.setTotal((long) listOfUsers.size());
        result.setMaxPages(1L);
        result.setResults(listOfUsers);

        return result.transform(UserTagsWrapperDTO.class);
    }

    public PaginationAndFullSearchQueryResult<UserRatingShortDTO> getUserRatingList(long userId) {
        List<UserRating> listOfUsers = usersDAO.getUserRatingByUserId(userId);

        PaginationAndFullSearchQueryResult<UserRating> result = new PaginationAndFullSearchQueryResult<>();
        result.setSuccess(true);
        result.setCode(200);
        result.setTotal((long) listOfUsers.size());
        result.setMaxPages(1L);
        result.setResults(listOfUsers);

        return result.transform(UserRatingShortDTO.class);
    }

    public List<UserRating> getUserRatingLists(long userId){
        return usersDAO.getUserRatingByUserId(userId);
    }

    public List<UserTags> getUserTagsLists(long userId){
        return usersDAO.getUserTagByUserId(userId);
    }

    @Transactional
    public Users getUserByUserIdAndTrainerType(long userId, boolean isTrainer){
        return usersDAO.getUserByUserIdAndTrainerType(userId, isTrainer);
    }

    @Transactional
    public Users updateUserProfile(Long id,String imgURL) {
        return usersDAO.updateUserProfile(id,imgURL);
    }

    @Transactional
    public RequestResponse updateUserProfileData(Long id, Users user){
        return usersDAO.updateUserProfileData(id,user);
    }

    @Transactional
    public RequestResponse setUserTag(Long userId, Integer id){
        return usersDAO.setUserTag(userId,id);
    }

    @Transactional
    public RequestResponse updateUserDescription(Long id, String description) {
        return usersDAO.updateUserDescription(id, description);
    }
}
