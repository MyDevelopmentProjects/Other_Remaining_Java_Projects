package ge.eduhack.dao;

import ge.eduhack.model.Users;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsersSearchDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        Predicate trainerFilter = null;
        Predicate starFilter = null;
        Predicate cityFilter = null;

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Users> criteriaQuery = criteriaBuilder.createQuery(Users.class);
        Root<Users> returnClassRoot = criteriaQuery.from(Users.class);
        returnClassRoot.alias(TABLE_ALIAS);

        Predicate adminFilter = criteriaBuilder.equal(returnClassRoot.get("superAdmin"), 0);
        Predicate activeFilter = criteriaBuilder.equal(returnClassRoot.get("active"), 1);

        if (objects != null && objects.length > 0 && objects[0] instanceof Boolean) {
            boolean isTraner = (Boolean) objects[0];
            trainerFilter = criteriaBuilder.equal(returnClassRoot.get("trainer"), isTraner ? 1 : 0);
        }

        if (objects != null && objects.length > 1 && objects[1] instanceof Integer) {
            if((int) objects[1] > 0){
                starFilter = criteriaBuilder.equal(returnClassRoot.get("starValue"), objects[1]);
            }
        }

        if (objects != null && objects.length > 2 && objects[2] instanceof Integer) {
            if((int) objects[2] > 0) {
                cityFilter = criteriaBuilder.equal(returnClassRoot.get("city").get("id"), objects[2]);
            }
        }

        List<Predicate> exprs = new ArrayList<>();

        if(adminFilter != null)
            exprs.add(criteriaBuilder.and(adminFilter));
        if (trainerFilter != null)
            exprs.add(criteriaBuilder.and(trainerFilter));
        if (starFilter != null)
            exprs.add(criteriaBuilder.and(starFilter));
        if (cityFilter != null)
            exprs.add(criteriaBuilder.and(cityFilter));
        exprs.add(criteriaBuilder.and(activeFilter));
        Predicate[] predicates = exprs.toArray(new Predicate[exprs.size()]);
        return criteriaBuilder.and(predicates);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Users.class) {
            fieldList.add("firstAndLast");
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}