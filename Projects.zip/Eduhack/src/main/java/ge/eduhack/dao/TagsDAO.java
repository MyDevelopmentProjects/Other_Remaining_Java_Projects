package ge.eduhack.dao;

import ge.eduhack.model.Tags;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class TagsDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Tags save(Tags tags) {
        if (tags.getId() != null) {
            em.merge(tags);
        } else {
            em.persist(tags);
        }
        return tags;
    }

    public void delete(Long id) {
        Tags role = em.find(Tags.class, id);
        em.remove(role);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Tags.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}