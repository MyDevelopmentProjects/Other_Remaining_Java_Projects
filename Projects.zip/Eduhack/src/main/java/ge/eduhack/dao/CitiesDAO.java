package ge.eduhack.dao;

import ge.eduhack.model.Cities;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CitiesDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Cities save(Cities city) {
        if (city.getId() != null) {
            em.merge(city);
        } else {
            em.persist(city);
        }
        return city;
    }

    public void delete(Long id) {
        Cities role = em.find(Cities.class, id);
        em.remove(role);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Cities.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}