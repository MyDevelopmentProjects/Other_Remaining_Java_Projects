package ge.eduhack.dao;

import ge.eduhack.model.Categories;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CategoriesDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Categories saveCategory(Categories category) {
        if (category.getId() != null) {
            em.merge(category);
        } else {
            em.persist(category);
        }
        return category;
    }

    public void deleteCategory(Long id) {
        Categories category = em.find(Categories.class, id);
        em.remove(category);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Categories.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

}