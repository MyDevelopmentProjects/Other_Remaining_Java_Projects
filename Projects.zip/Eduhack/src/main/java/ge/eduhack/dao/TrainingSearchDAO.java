package ge.eduhack.dao;

import ge.eduhack.model.Training;
import ge.eduhack.model.Users;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class TrainingSearchDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {

        Predicate nameFilter = null;
        Predicate categoryFilter = null;
        Predicate cityFilter = null;

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Users> criteriaQuery = criteriaBuilder.createQuery(Users.class);
        Root<Users> returnClassRoot = criteriaQuery.from(Users.class);
        returnClassRoot.alias(TABLE_ALIAS);

        if (objects != null && objects.length > 0 && objects[0] instanceof String) {
            String name = String.valueOf(objects[0]);
            nameFilter = criteriaBuilder.like(returnClassRoot.get("name"), name);
        }

        if (objects != null && objects.length > 1 && objects[1] instanceof Long) {
            categoryFilter = criteriaBuilder.equal(returnClassRoot.get("category").get("id"), objects[1]);
        }

        if (objects != null && objects.length > 2 && objects[2] instanceof Long) {
            cityFilter = criteriaBuilder.equal(returnClassRoot.get("city").get("id"), objects[2]);
        }

        return criteriaBuilder.and(
                nameFilter,
                categoryFilter,
                cityFilter
        );
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Training.class) {
        }
        return fieldList;
    }

}