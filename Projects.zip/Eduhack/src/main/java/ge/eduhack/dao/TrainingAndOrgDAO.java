package ge.eduhack.dao;

import ge.eduhack.model.Training;
import ge.eduhack.model.Users;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 * Created by Mikha on 9/20/2016.
 */
@Repository
public class TrainingAndOrgDAO {

    @PersistenceContext
    private EntityManager em;

    public long getTrainingCount(){
        CriteriaBuilder qb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = qb.createQuery(Long.class);
        Root<Training> returnClassRoot = cq.from(Training.class);
        cq.select(qb.count(returnClassRoot));
        cq.where(qb.equal(returnClassRoot.get("approved"), true));
        return em.createQuery(cq).getSingleResult();
    }

    public long getTrainerOrOrganisationCount(boolean isTrainer){
        CriteriaBuilder qb = em.getCriteriaBuilder();
        CriteriaQuery<Long> cq = qb.createQuery(Long.class);
        Root<Users> returnClassRoot = cq.from(Users.class);
        cq.select(qb.count(returnClassRoot));
        cq.where(
            qb.equal(returnClassRoot.get("superAdmin"), false),
            qb.equal(returnClassRoot.get("active"), true),
            qb.equal(returnClassRoot.get("trainer"), isTrainer)
        );
        return em.createQuery(cq).getSingleResult();
    }
}
