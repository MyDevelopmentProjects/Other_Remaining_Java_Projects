package ge.eduhack.dao;

import ge.eduhack.config.exception.MGLException;
import ge.eduhack.config.exception.MGLExceptionForUser;
import ge.eduhack.model.Roles;
import ge.eduhack.model.UserRating;
import ge.eduhack.model.UserTags;
import ge.eduhack.model.Users;
import ge.eduhack.utils.MGLUserUtils;
import ge.eduhack.utils.RequestResponse;
import ge.eduhack.utils.constants.Constants;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsersDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @SuppressWarnings("unchecked")
    public Users findByUserName(String username) throws MGLExceptionForUser {
        List<Users> users;
        users = em.createQuery("from Users where userName=:username and active = true")
                .setParameter("username", username)
                .getResultList();
        if (users != null && users.size() > 0) {
            return users.get(0);
        }
        throw new MGLExceptionForUser(Constants.ErrorCodes.ErrorMessages.INCORRECT_CREDS);
    }

    public Users checkIfUserExists(String username, String password) {
        Users user = null;
        try {
            user = (Users) em.createQuery("FROM Users WHERE userName=:username AND password=:password")
                    .setParameter("username", username)
                    .setParameter("password", password)
                    .getSingleResult();
        } catch (Exception ignored) {
        }
        return user;
    }

    public boolean checkIfUserExists(String username) {
        Users user = null;
        try {
            user = (Users) em.createQuery("FROM Users WHERE userName=:username")
                    .setParameter("username", username)
                    .getSingleResult();
        } catch (Exception ignored) {
        }
        return user != null;
    }

    public Users saveUser(Users user) {

        Roles role = new Roles();

        if (!user.isSuperAdmin()) {
            role.setId(1L);
            user.setRole(role);
        } else {
            role.setId(2L);
            user.setRole(role);
        }

        if (user.getId() != null) {
            em.merge(user);
        } else {
            em.persist(user);
        }
        return user;
    }

    public void deleteUser(Long id) throws MGLException, NoSuchMethodException, IllegalAccessException, InvocationTargetException {
        Users user = em.find(Users.class, id);
        //MGLDAORemovalManager.canExecute(user);
        em.remove(user);
    }

    public Users updateUserProfile(Long id, String imgURL){
        Users user = em.find(Users.class, id);
        user.setImgUrl(imgURL);
        em.merge(user);
        MGLUserUtils.refreshAuthorisedUser(em.find(Users.class, id));
        return user;
    }


    public RequestResponse updateUserProfileData(Long id, Users userData){
        Users user = em.find(Users.class, id);
        RequestResponse response = new RequestResponse();
        if(user == null){
            response.setSuccess(false);
            response.setErrorMessage("დაფიქსირდა შეცდომა.");
            return response;
        }
        if(!user.getPassword().equals(userData.getPassword())){
            response.setSuccess(false);
            response.setErrorMessage("არასწორი პაროლი, თქვენი მოთხოვნა ვერ შესრულდა.");
            return response;
        }
        em.merge(userData);
        MGLUserUtils.refreshAuthorisedUser(em.find(Users.class, id));
        return RequestResponse.SUCCESS();
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Users.class) {
            fieldList.add("firstAndLast");
            fieldList.add("name");
            fieldList.add("email");
            fieldList.add("mNumber");
            fieldList.add("dateCreated");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    @SuppressWarnings("unchecked")
    public List<Users> getPopulars(boolean isTrainer) {
        List<Users> list = null;

        try {
            String q = "FROM Users WHERE trainer = :isTrainer AND superAdmin=:superAdmin AND active = 1 ORDER BY starValue DESC, id DESC, dateUpdated DESC";
            list = (List<Users>) em.createQuery(q)
                    .setParameter("isTrainer", isTrainer)
                    .setParameter("superAdmin", false)
                    .setMaxResults(3)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @SuppressWarnings("unchecked")
    public List<UserTags> getUserTagByUserId(long userId){
        List<UserTags> list = null;

        try {
            String q = "FROM UserTags WHERE user.id = :userId";
            list = (List<UserTags>) em.createQuery(q)
                    .setParameter("userId", userId)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @SuppressWarnings("unchecked")
    public Users getUserByUserIdAndTrainerType(long userId, boolean isTrainer){
        Users user = null;
        try {
            String q = "FROM Users WHERE id = :userId AND trainer = :isTrainer ";
            user = (Users) em.createQuery(q)
                    .setParameter("userId", userId)
                    .setParameter("isTrainer", isTrainer)
                    .getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return user;
    }

    @SuppressWarnings("unchecked")
    public List<UserRating> getUserRatingByUserId(long userId) {
        List<UserRating> list = null;

        try {
            String q = "FROM UserRating WHERE owner.id = :userId";
            list = (List<UserRating>) em.createQuery(q)
                    .setParameter("userId", userId)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public RequestResponse setUserTag(long userId, int tagId) {
        Users user = em.find(Users.class, userId);
        RequestResponse response = new RequestResponse();
        if(user == null) {
            response.setSuccess(false);
            response.setErrorMessage("დაფიქსირდა შეცდომა.");
            return response;
        }

        try {

            long rowCount = ((Number) em.createNativeQuery(String.format("SELECT count(*) FROM user_tags WHERE user_id = %d AND tag_id= %d", userId, tagId))
                    .getSingleResult()).longValue();

            if(rowCount > 0){
                String sql = String.format("DELETE FROM user_tags WHERE user_id = %d AND tag_id= %d", userId, tagId);
                em.createNativeQuery(sql).executeUpdate();
            } else {
                String sql = String.format("INSERT INTO user_tags (user_id,tag_id) " + " VALUES (%d,%d)", userId, tagId);
                em.createNativeQuery(sql).executeUpdate();
            }
        }
        catch (NoResultException nre){
            //Ignore this because as per your logic this is ok!
            return RequestResponse.ERROR();
        }

        return RequestResponse.SUCCESS();
    }

    public RequestResponse updateUserDescription(Long userId, String description) {
        Users user = em.find(Users.class, userId);
        RequestResponse response = new RequestResponse();
        if(user == null) {
            response.setSuccess(false);
            response.setErrorMessage("დაფიქსირდა შეცდომა.");
            return response;
        }
        if(description.equals("")){
            description = null;
        }
        user.setDescription(description);
        em.merge(user);
        MGLUserUtils.refreshAuthorisedUser(em.find(Users.class, userId));
        return RequestResponse.SUCCESS();
    }
}