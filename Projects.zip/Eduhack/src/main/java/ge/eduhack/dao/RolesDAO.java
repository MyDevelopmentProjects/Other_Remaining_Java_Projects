package ge.eduhack.dao;

import ge.eduhack.model.Roles;
import ge.eduhack.utils.MGLUserUtils;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@Repository
public class RolesDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    public Roles saveRole(Roles role) {
        if (role.getId() != null) {
            em.merge(role);
        } else {
            em.persist(role);
        }
        return role;
    }

    public Roles createAutomaticRole(Roles role) {
        em.persist(role);
        return role;
    }

    public List getRolePermissionsByRoleId(long roleId) {
        Query q = em.createNativeQuery("SELECT permission_id FROM role_permissions WHERE role_id = " + roleId);
        try {
            return q.getResultList();
        } catch (Exception ignored) {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    public boolean saveRolePermission(String json) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            HashMap<String, Object> obj = (HashMap<String, Object>) mapper.readValue(json, HashMap.class);
            Long roleId = Long.valueOf(obj.get("roleId").toString());
            List<Integer> permissions = (List<Integer>) obj.get("permissions");
            if (roleId != null && permissions != null) {
                if (!MGLUserUtils.isSuperAdmin()) {
                    if (!validateRequest(permissions))
                        return false;
                }
                deleteRolePermission(roleId);
                for (Integer permissionId : permissions) {
                    String sql = String.format("INSERT INTO role_permissions (role_id,permission_id) " +
                            "VALUES (%d,%d)", roleId, permissionId);
                    em.createNativeQuery(sql).executeUpdate();
                }
            }
        } catch (Exception ignored) {
            return false;
        }
        return true;
    }

    /***
     * @param items list of permission ids sent from client
     * @return false if there is at least one permission id which has property super admin
     */
    private boolean validateRequest(List<Integer> items) {
        Collections.sort(items);
        return items.get(items.size() - 1) <= 100;
    }

    public void deleteRolePermission(Long roleId) {
        Query q = em.createNativeQuery("DELETE FROM role_permissions WHERE role_id = " + roleId);
        try {
            q.executeUpdate();
        } catch (Exception ignored) {
        }
    }

    public void deleteRole(Long id) {
        Roles role = em.find(Roles.class, id);
        em.remove(role);
    }

    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Roles.class) {
            fieldList.add("role");
        }
        return fieldList;
    }

    @Override
    public EntityManager getEntityManager() {
        return em;
    }

    public void saveListOfRolePermission(String query) {
        Query q = em.createNativeQuery(query);
        try {
            q.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}