package ge.eduhack.dao;

import ge.eduhack.model.Training;
import ge.eduhack.model.TrainingTrainers;
import ge.eduhack.model.Users;
import ge.eduhack.utils.MGLUserUtils;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQuery;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@Repository
public class TrainingDAO extends PaginationAndFullSearchQuery {

    @PersistenceContext
    private EntityManager em;

    @Override
    public EntityManager getEntityManager() {
        return em;
    }


    @Override
    public <T> List<String> getFieldsAvailableForFullTextSearch(Class<T> resultClass) {
        List<String> fieldList = new ArrayList<String>();
        if (resultClass == Training.class) {
            fieldList.add("name");
        }
        return fieldList;
    }

    public Training save(Training training, boolean forUser) {
        if(forUser){
            training.setCreatedBy(MGLUserUtils.getCurrentUser());
        }
        if (training.getId() != null) {
            em.merge(training);
            return training;
        } else {
            em.persist(training);
            return training;
        }
    }

    public boolean update(Training training) {
        if (training.getId() != null) {
            Training t = em.find(Training.class, training.getId());
            if (!t.getCreatedBy().getId().equals(MGLUserUtils.getCurrentUser().getId())) {
                return false;
            }
            t.setImgUrl(training.getImgUrl());
            em.merge(t);
            return true;
        }
        return false;
    }

    public void approveTraining(Long id){
        Training training = em.find(Training.class, id);
        training.setApproved(!training.getApproved());
        em.merge(training);
    }

    public void delete(Long id) {
        removeRelationalTableByTrainingId(id);
        Training training = em.find(Training.class, id);
        em.remove(training);
    }

    @Override
    public <T> Predicate getPDQExpression(Class<T> resultClass, Object... objects) {
        Predicate approvedFilter = null;
        Predicate categoryFilter = null;
        Predicate cityFilter = null;

        EntityManager entityManager = getEntityManager();
        CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Training> criteriaQuery = criteriaBuilder.createQuery(Training.class);
        Root<Training> returnClassRoot = criteriaQuery.from(Training.class);
        returnClassRoot.alias(TABLE_ALIAS);

        if(objects != null && objects.length > 0){
            approvedFilter = criteriaBuilder.equal(returnClassRoot.get("approved"), true);
        }

        if (objects != null && objects.length > 0 && objects[0] instanceof Long && ((long) objects[0] > 0)) {
            categoryFilter = criteriaBuilder.equal(returnClassRoot.get("category").get("id"), objects[0]);
        }

        if (objects != null && objects.length > 1 && objects[1] instanceof Long && ((long) objects[1] > 0)) {
            cityFilter = criteriaBuilder.equal(returnClassRoot.get("city").get("id"), objects[1]);
        }

        List<Predicate> exprs = new ArrayList<>();

        if(approvedFilter != null) {
            exprs.add(criteriaBuilder.and(approvedFilter));
        }
        if (categoryFilter != null) {
            exprs.add(criteriaBuilder.and(categoryFilter));
        }
        if (cityFilter != null) {
            exprs.add(criteriaBuilder.and(cityFilter));
        }
        Predicate[] predicates = exprs.toArray(new Predicate[exprs.size()]);
        return criteriaBuilder.and(predicates);
    }

    public void updateObjects(String[] values, Long trainingId) {
        Training training = em.find(Training.class, trainingId);
        if(training != null) {
            for (String id : values) {
                Users user = em.find(Users.class, Long.valueOf(id));
                if (user != null) {
                    TrainingTrainers tt = new TrainingTrainers();
                    tt.setCreatorId(MGLUserUtils.getCurrentUser().getId());
                    tt.setTraining(training);
                    tt.setTrainingObject(user);
                    em.persist(tt);
                }
            }
        }
    }

    @SuppressWarnings("unchecked")
    public void removeRelationalTableByTrainingId(long trainingId){
        String q = "DELETE FROM TrainingTrainers where training.id =:training";
        try {
            em.createQuery(q).setParameter("training", trainingId)
                    .executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    public Training getTrainingById(long trainingId) {
        Training training = null;
        String q = "FROM Training WHERE id = :id AND approved = :isApproved";
        try {
            training = (Training) em.createQuery(q)
                    .setParameter("id", trainingId)
                    .setParameter("isApproved", true)
                    .getSingleResult();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return training;
    }

    @SuppressWarnings("unchecked")
    public List<TrainingTrainers> getOrganisationAndTrainerByTrainingId(long trainingId){
        List<TrainingTrainers> trt = null;
        String q = "FROM TrainingTrainers WHERE training.id = :id";
        try {
            trt = (List<TrainingTrainers>) em.createQuery(q)
                    .setParameter("id", trainingId)
                    .getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return  trt;
    }
}