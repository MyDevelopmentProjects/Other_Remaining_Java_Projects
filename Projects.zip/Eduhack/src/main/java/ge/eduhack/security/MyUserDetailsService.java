package ge.eduhack.security;

import ge.eduhack.config.exception.MGLExceptionForUser;
import ge.eduhack.dao.UsersDAO;
import ge.eduhack.model.Users;
import ge.eduhack.utils.MGLStringUtils;
import ge.eduhack.utils.constants.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service("userDetailsService")
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    public UsersDAO usersDao;

    @Transactional(readOnly = true)
    @Override
    public UserDetails loadUserByUsername(final String username) throws MGLExceptionForUser {
        if (MGLStringUtils.IsNullOrBlank(username)) {
            throw new UsernameNotFoundException(Constants.ErrorCodes.ErrorMessages.USER_NOT_FOUND);
        }
        Users user = usersDao.findByUserName(username);

        List<GrantedAuthority> grantedAuthorities = user.getRole().getPermissions().stream().map(
                permission -> new SimpleGrantedAuthority(permission.getName())
        ).collect(Collectors.toList());

        // Load User Role
        grantedAuthorities.add(new SimpleGrantedAuthority(user.getRole().getRole()));

        return new UserRepositoryUserDetails(user, grantedAuthorities);
    }


    private final static class UserRepositoryUserDetails extends Users implements UserDetails {
        private List<? extends GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

        private UserRepositoryUserDetails(Users user, List<? extends GrantedAuthority> authorities) {
            super(user);
            this.authorities = authorities;
        }

        @Override
        public Collection<? extends GrantedAuthority> getAuthorities() {
            return authorities;
        }

        @Override
        public String getUsername() {
            return getUserName();
        }

        @Override
        public boolean isAccountNonExpired() {
            return true;
        }

        @Override
        public boolean isAccountNonLocked() {
            return true;
        }

        @Override
        public boolean isCredentialsNonExpired() {
            return true;
        }

        @Override
        public boolean isEnabled() {
            return true;
        }

        private static final long serialVersionUID = 5639683223516504866L;
    }

}
