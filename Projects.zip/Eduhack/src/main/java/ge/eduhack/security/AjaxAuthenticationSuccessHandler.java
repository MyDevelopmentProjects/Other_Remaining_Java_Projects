package ge.eduhack.security;

import ge.eduhack.dto.UsersLoginDTO;
import ge.eduhack.model.Users;
import ge.eduhack.utils.pagination.PaginationAndFullSearchQueryResult;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Authentication success handler for integration with SPA applications that need to login using Ajax instead of
 * a form post.
 * <p>
 * Detects if its a ajax login request, and if so sends a customized response in the body, otherwise defaults
 * to the existing behaviour for none-ajax login attempts.
 */
public class AjaxAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private AuthenticationSuccessHandler defaultHandler;

    public AjaxAuthenticationSuccessHandler(AuthenticationSuccessHandler defaultHandler) {
        this.defaultHandler = defaultHandler;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request,
                                        HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {

        if ("true".equals(request.getHeader("X-Login-Ajax-call"))) {
            Users user = (Users) authentication.getPrincipal();

            List<Users> listOfUsers = new ArrayList<>(1);
            listOfUsers.add(user);

            PaginationAndFullSearchQueryResult<Users> result = new PaginationAndFullSearchQueryResult<>();
            result.setCode(200);
            result.setMaxPages(1L);
            result.setSuccess(true);
            result.setTotal(1L);
            result.setResults(listOfUsers);

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonInString = objectMapper.writeValueAsString(result.transform(UsersLoginDTO.class));
            response.setStatus(200);
            response.getWriter().print(jsonInString);
            response.setHeader("Content-Type", "application/json");
            response.getWriter().flush();

        } else {
            defaultHandler.onAuthenticationSuccess(request, response, authentication);
        }

    }
}