angular.module('App.controllers').controller('TrainingController',
    ['$rootScope', '$scope', '$http', 'GridManager', 'ModalManager', function ($rootScope, $scope, $http, GridManager, ModalManager) {

        angular.extend($scope, {
            url:'training/list',
            saveURL:'training/public/save',
            deleteURL:'training/delete',
            userListURL:'user/list?pageSize=-255',
            categoryListURL:'category/list?pageSize=-255',
            citiesListURL:'/cities/list?pageSize=-255',
            states:[
                {name:"გამოქვეყნებულია"},
                {name:"დაფარულია"}
            ],
            selected_trainer_users:[],
            selected_organisation_users:[],
            init:{}
        });

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.AmfTable.openPage(0);

        $scope.showAddEdit = function (item) {
            $scope.init.action = item ? 'Edit' : 'Add';
            $scope.object = {};
            $scope.object.createdBy = null;
            $scope.selected_trainer_users = [];
            $scope.selected_organisation_users = [];
            if (item) {
                $scope.object = angular.copy(item);
                if ($scope.object.dateFrom != null) {
                    $scope.object.dateFrom = $scope.timeToDateShort($scope.object.dateFrom);
                }
                if ($scope.object.dateTo != null) {
                    $scope.object.dateTo = $scope.timeToDateShort($scope.object.dateTo);
                }
                $scope.loadTrainingTrainer($scope.object.id);
            }
            $scope.loadUserList();
            $scope.loadCategoryList();
            $scope.loadCitiesList();
            $('#showAddEdit').modal('show');
        };

        $scope.save = function () {
            if($scope.selected_trainer_users.length == 0 || $scope.selected_organisation_users.length == 0){
                $scope.showErrorModal("გთხოვთ აირჩიეთ ორგანიზაცია და ტრენერი", false);
                return;
            }

            $http.post($scope.saveURL, $scope.object).success(function (response) {
                if (response > 0) {
                    $scope.saveTrainingDetails(response);
                } else {
                    $scope.showErrorModal("შენახვა ვერ მოხერხდა. სცადეთ თავიდან", false);
                }
            });
        };

        $scope.saveTrainingDetails = function (trainingId) {
            if(trainingId == undefined){
                return;
            }
            var numArr = [];
            for (var i = 0; i < $scope.selected_trainer_users.length; i++)
                numArr.push($scope.selected_trainer_users[i].id)
            for (var i = 0; i < $scope.selected_organisation_users.length; i++)
                numArr.push($scope.selected_organisation_users[i].id)

            $http.post("training/updateObjects?ids=" + numArr + "&trainingId=" + trainingId)
                .success(function (data) {
                    if (data.success) {
                        $scope.showSuccessAlert("ოპერაცია შესრულდა წარმატებით", true);
                    } else {
                        $scope.showErrorModal("შენახვა ვერ მოხერხდა. სცადეთ თავიდან", false);
                    }

                    $scope.saveTrainingDetails();
                    $scope.showSuccessAlert("Success", true);
                    $scope.AmfTable.reloadData(true);
                    $('#showAddEdit').modal('hide');
                });
        };

        $scope.approve = function (itemId) {
            $http.post("training/approve", itemId)
                .success(function (data) {
                    if (!data.success) {
                        $scope.showErrorModal("შენახვა ვერ მოხერხდა. სცადეთ თავიდან", false);
                        return;
                    }
                    $scope.showSuccessAlert("თქვენი მოთხოვნა წარმატებით დასრულდა", true);
                    $scope.AmfTable.reloadData(true);
                });
        };

        $scope.delete = function (itemId) {
            $http.post($scope.deleteURL, itemId).success(function (response) {
                if (!response.success) {
                    if(response.errorMessage == "RECORD_IS_USED_IN_OTHER_TABLES"){
                        $scope.showErrorModal("მოცემული ჩანაწერის წაშლა შეუძლებელია რადგან ის ფიქსირდება სხვა ცხრილშიც.")
                    }
                    return;
                }
                $scope.showSuccessAlert("Success", true);
                $scope.AmfTable.reloadData(true);
            });
        };

        $scope.loadUserList = function (){
            $http.get($scope.userListURL).success(function (response){
                if(!response.success){
                    $scope.showErrorModal("Error", false);
                    return
                }
                $scope.userList = response.results;
            });
        };

        $scope.loadCategoryList = function(){
            $http.get($scope.categoryListURL).success(function (response) {
                if(!response.success){
                    $scope.showErrorModal("Error", false);
                    return;
                }
                $scope.categoryList = response.results;
            });
        };

        $scope.loadCitiesList = function(){
            $http.get($scope.citiesListURL).success(function (response) {
                if(!response.success){
                    $scope.showErrorModal("Error", false);
                    return;
                }
                $scope.cityList = response.results;
            });
        };

        $scope.$on('upload-finished', function (event, args) {
            if(args.data == "") { $scope.object.imgUrl = null; }
            if (args.data && args.data.length > 0) {
                $scope.object.imgUrl = args.data[0];
            }
        });

        $scope.showSearchModalForCreator = function(){
            $rootScope.$emit('loadCreatorList', {load:true});
            $('#showAddEdit').modal('hide');
            $('#showUserSearch').modal('show');
        };

        $scope.showSearchModal = function(trainer){
            $scope.isTrainer = trainer;
            $rootScope.$emit('loadSearchingUsers', {load:true, isTrainer:trainer});
            $('#showAddEdit').modal('hide');
            $('#showUserSearch').modal('show');
        };

        $rootScope.$on('user_trainer_or_org_selected', function(event, newPerson){
            if($scope.isTrainer) {
                if ($scope.selected_trainer_users.length == 20) {
                    $scope.showErrorModal("20-ზე მეტი ტრენერის დამატება შეუძლებელია", false);
                    return;
                }

                var exists = false;
                angular.forEach($scope.selected_trainer_users, function (object) {
                    if (object && object.id == newPerson.id) {
                        exists = true;
                    }
                });

                if (!exists) {
                    $scope.selected_trainer_users.push(newPerson);
                } else {
                    $scope.showErrorModal("ასეთი მომხმარებელი უკვე არსებობს.", false);
                }
            } else {
                if ($scope.selected_organisation_users.length == 20) {
                    $scope.showErrorModal("20-ზე მეტი ორგანიზაციის დამატება შეუძლებელია", false);
                    return;
                }

                var exists = false;
                angular.forEach($scope.selected_organisation_users, function (object) {
                    if (object && object.id == newPerson.id) {
                        exists = true;
                    }
                });

                if (!exists) {
                    $scope.selected_organisation_users.push(newPerson);
                } else {
                    $scope.showErrorModal("ასეთი მომხმარებელი უკვე არსებობს.", false);
                }
            }
        });

        $rootScope.$on('creator_selected', function(event, newPerson){
            $scope.object.createdBy = newPerson;
        });

        $scope.removeSelectedUser = function (item, isTrainer) {
            if(isTrainer) {
                $scope.selected_trainer_users.splice(item, 1);
            }else {
                $scope.selected_organisation_users.splice(item, 1);
            }
        };

        $scope.removeSelectedCreator = function(){
            $scope.object.createdBy = null;
        };

        $scope.loadTrainingTrainer = function(trainingId){
            $http.get('training/training-trainer/list/'+trainingId).success(function (response) {
                if(response.length > 0){
                    angular.forEach(response, function (object) {
                        if (object.trainingObject.trainer){
                            $scope.selected_trainer_users.push(object.trainingObject);
                        } else {
                            $scope.selected_organisation_users.push(object.trainingObject);
                        }
                    });
                }
            });
        };
    }]);