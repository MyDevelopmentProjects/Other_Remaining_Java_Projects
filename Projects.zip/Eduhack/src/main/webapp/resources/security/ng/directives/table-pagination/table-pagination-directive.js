angular.module('App').directive('appTablePagination', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/security/ng/directives/table-pagination/table-pagination.jsp'
    };
});