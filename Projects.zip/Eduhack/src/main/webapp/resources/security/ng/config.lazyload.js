// lazyload config
(function() {
    'use strict';
    angular
		.module('App')
		.constant('MODULE_CONFIG', [
			{
				name: 'chart',
				module: false,
				files: [
					'resources/libs/js/echarts/build/dist/echarts-all.js',
					'resources/libs/js/echarts/build/dist/theme.js',
					'resources/libs/js/echarts/build/dist/jquery.echarts.js'
				]
			}
        ])
		.config(['$ocLazyLoadProvider', 'MODULE_CONFIG', function($ocLazyLoadProvider, MODULE_CONFIG) {
			$ocLazyLoadProvider.config({
				debug: false,
				events: false,
				modules: MODULE_CONFIG
			});
		}]);
})();

