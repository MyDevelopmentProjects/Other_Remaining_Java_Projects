(function() {
    'use strict';
    angular
        .module('App', [
            'ngAnimate',
            'ngResource',
            'ngCookies',
            'ui.router',
			'ui.bootstrap',
            'ui.mask',
            'oc.lazyLoad'
        ]);
})();
