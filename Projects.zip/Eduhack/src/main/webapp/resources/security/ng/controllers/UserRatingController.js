angular.module('App.controllers').controller('UserRatingController',
    ['$rootScope', '$scope', '$http', 'GridManager', 'ModalManager', function ($rootScope, $scope, $http, GridManager, ModalManager) {

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);

        $rootScope.$on('loadUserRating', function(event, data) {
            if(parseInt(data.user_id)){
                $scope.url = "user/rating?userId=" + data.user_id;
                $scope.AmfTable.openPage(0);
            }
        });
    }]);