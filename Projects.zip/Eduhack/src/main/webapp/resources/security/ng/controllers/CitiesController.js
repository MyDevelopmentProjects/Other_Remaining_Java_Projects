angular.module('App.controllers').controller('CitiesController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        angular.extend($scope, {
            url:'cities/list',
            saveURL:'cities/save',
            deleteURL:'cities/delete',
            init:{}
        });

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.AmfTable.openPage(0);

        $scope.showAddEdit = function (item) {
            $scope.init.action = item ? 'Edit' : 'Add';
            $scope.object = {};
            if (item) {
                $scope.object = angular.copy(item);
            }
            $('#showAddEdit').modal('show');
        };

        $scope.save = function () {
            $http.post($scope.saveURL, $scope.object).success(function (response) {
                if (!response.success) {
                    return;
                }
                $scope.showSuccessAlert("Success", true);
                $scope.AmfTable.reloadData(true);
                $('#showAddEdit').modal('hide');
            });
        };

        $scope.delete = function (itemId) {
            $http.post($scope.deleteURL, itemId).success(function (response) {
                if (!response.success) {
                    return;
                }
                $scope.showSuccessAlert("Success", true);
                $scope.AmfTable.reloadData(true);
            });
        };

    }]);