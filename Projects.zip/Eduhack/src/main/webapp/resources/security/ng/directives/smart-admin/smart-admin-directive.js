angular.module('App')
    .directive('widget', function () {
        return {
            restrict: 'AE',
            transclude: true,
            replace: true,
            scope: {
                color: '@'
            },
            template: '<div class="jarviswidget {{color}}" data-ng-transclude=""></div>'
        }
    })
    .directive('widgetHeader', function () {
        return {
            restrict: 'AE',
            transclude: true,
            replace: true,
            scope: {
                title: '@',
                icon: '@'
            },
            template: '\
                    <header>\
                        <span class="widget-icon"> <i data-ng-class="icon"></i> </span>\
                        <h2 data-localize="{{ title }}">{{ title }}</h2>\
                        <span data-ng-transclude></span>\
                    </header>'
        }
    })
    .directive('action', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var smartActions = {
                    // LOGOUT MSG
                    userLogout: function ($this) {
                        // ask verification
                        $.SmartMessageBox({
                            title: "<i class='fa fa-sign-out txt-color-orangeDark'></i> Are you sure you want to log out <span class='txt-color-orangeDark'><strong>" + $('#show-shortcut').text() + "</strong></span> ?",
                            content: $this.data('logout-msg') || "",
                            buttons: '[No][Yes]'
                        }, function (ButtonPressed) {
                            if (ButtonPressed == "Yes") {
                                $("body").addClass('animated fadeOutUp');
                                setTimeout(logout, 1000);
                            }
                        });
                        function logout() {
                            window.location = $this.attr('href');
                        }
                    },
                    // LAUNCH FULLSCREEN
                    launchFullscreen: function (element) {
                        if (!$("body").hasClass("full-screen")) {
                            $("body").addClass("full-screen");
                            if (element.requestFullscreen) {
                                element.requestFullscreen();
                            } else if (element.mozRequestFullScreen) {
                                element.mozRequestFullScreen();
                            } else if (element.webkitRequestFullscreen) {
                                element.webkitRequestFullscreen();
                            } else if (element.msRequestFullscreen) {
                                element.msRequestFullscreen();
                            }
                        } else {
                            $("body").removeClass("full-screen");
                            if (document.exitFullscreen) {
                                document.exitFullscreen();
                            } else if (document.mozCancelFullScreen) {
                                document.mozCancelFullScreen();
                            } else if (document.webkitExitFullscreen) {
                                document.webkitExitFullscreen();
                            }
                        }
                    },
                };

                var actionEvents = {
                    userLogout: function (e) {
                        smartActions.userLogout(element);
                    },
                    launchFullscreen: function (e) {
                        smartActions.launchFullscreen(document.documentElement);
                    }
                };

                if (angular.isDefined(attrs.action) && attrs.action != '') {
                    var actionEvent = actionEvents[attrs.action];
                    if (typeof actionEvent === 'function') {
                        element.on('click', function (e) {
                            actionEvent(e);
                            e.preventDefault();
                        });
                    }
                }

            }
        };
    });
