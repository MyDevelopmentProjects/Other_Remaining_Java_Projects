angular.module('App.controllers').controller('TagsController',
    ['$scope', '$http', 'GridManager', 'ModalManager', function ($scope, $http, GridManager, ModalManager) {

        angular.extend($scope, {
            url:'tags/list',
            saveURL:'tags/save',
            deleteURL:'tags/delete',
            tagTypes: [
                {id:0, name:"რესურსები"},
                {id:1, name:"ინტერესები"}
            ],
            init:{}
        });

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.AmfTable.openPage(0);

        $scope.showAddEdit = function (item) {
            $scope.init.action = item ? 'Edit' : 'Add';
            $scope.object = {};
            if (item) {
                $scope.object = angular.copy(item);
            }
            $('#showAddEdit').modal('show');
        };

        $scope.save = function () {
            $http.post($scope.saveURL, $scope.object).success(function (response) {
                if (!response.success) {
                    return;
                }
                $scope.showSuccessAlert("Success", true);
                $scope.AmfTable.reloadData(true);
                $('#showAddEdit').modal('hide');
            });
        };

        $scope.delete = function (itemId) {
            $http.post($scope.deleteURL, itemId).success(function (response) {
                if (!response.success) {
                    $scope.showErrorModal("Error, Record cant be deleted it is already in use.");
                    return;
                }
                $scope.showSuccessAlert("Success", true);
                $scope.AmfTable.reloadData(true);
            });
        };
    }]);