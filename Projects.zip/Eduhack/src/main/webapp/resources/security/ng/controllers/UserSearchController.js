angular.module('App.controllers').controller('UserSearchController',
    ['$rootScope', '$scope', '$http', 'GridManager', 'ModalManager', function ($rootScope, $scope, $http, GridManager, ModalManager) {

        angular.extend($scope, {
            init:{}
        });

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);

        $rootScope.$on('loadCreatorList', function(event, data){
           if(data.load){
               $scope.init = false;
               $scope.url = 'user/list';
               $scope.AmfTable.pageLimit = 30;
               $scope.AmfTable.openPage(0);
           }
        });

        $rootScope.$on('loadSearchingUsers', function(event, data) {
            if(data.load){
                $scope.init = true;
                $scope.url = 'search/user?isTrainer='+data.isTrainer;
                $scope.AmfTable.pageLimit = 30;
                $scope.AmfTable.openPage(0);
            }
        });

        $('#showUserSearch').on("hidden.bs.modal", function(){
            $('#showAddEdit').modal('show');
        });

        $scope.addToTraining = function(event, item){
            // Disable add button
            var target = $(event.target);
            if(!target.hasClass('disabled')){
                target.toggleClass('disabled');
                $rootScope.$emit('user_trainer_or_org_selected', item);
            }
        };

        $scope.addCreator = function(event, item){
            // Disable add button
            var target = $(event.target);
            if(!target.hasClass('disabled')){
                target.toggleClass('disabled');
                $rootScope.$emit('creator_selected', item);
                $("#showUserSearch").modal('hide');
            }
        };

    }]);