angular.module('App').directive('appTableSearchInput', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/security/ng/directives/table-search/table-search.jsp'
    };
});