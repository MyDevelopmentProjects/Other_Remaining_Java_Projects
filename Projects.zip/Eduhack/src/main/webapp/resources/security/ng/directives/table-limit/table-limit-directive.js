angular.module('App').directive('appTableLimit', function () {
    return {
        restrict: 'E',
        templateUrl: 'resources/security/ng/directives/table-limit/table-limit.jsp'
    };
});