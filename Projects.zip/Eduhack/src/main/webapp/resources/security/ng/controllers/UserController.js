angular.module('App.controllers').controller('UserController',
    ['$rootScope', '$scope', '$http', 'GridManager', 'ModalManager', function ($rootScope, $scope, $http, GridManager, ModalManager) {

        angular.extend($scope, {
            url:'user/list',
            saveURL:'user/save',
            deleteURL:'user/delete',
            citiesListURL:'cities/list?pageSize=-255',
            init:{edit:false}
        });

        $scope.tagTypes = [
            {name:"რესურსები"},
            {name:"ინტერესები"}
        ];
        $scope.genderOptions = [
            {id: 1, name: "მამრობითი", value: true},
            {id: 2, name: "მდედრობითი", value: false}
        ];

        GridManager.givePowerTo($scope);
        ModalManager.enableModals($scope);
        $scope.AmfTable.openPage(0);

        $scope.showAddEdit = function (item) {
            $scope.init.action = item ? 'Edit' : 'Add';
			$scope.object = {};
            if (item) {
                $scope.object = angular.copy(item);
                if ($scope.object.dob != null) {
                    $scope.object.dob = $scope.timeToDateShort($scope.object.dob);
                }
            }
            $scope.loadCitiesList();
            $('#showAddEdit').modal('show');
        };

        $scope.save = function () {
            $http.post($scope.saveURL, $scope.object).success(function (response) {
				if (!response.success) { 
					return;
				}
				$scope.showSuccessAlert("Success", true);
				$scope.AmfTable.reloadData(true);
				$('#showAddEdit').modal('hide');
			});
        };

        $scope.delete = function (itemId) {
            $http.post($scope.deleteURL, itemId).success(function (response) {
				if (!response.success) {
				    if(response.errorMessage == "RECORD_IS_USED_IN_OTHER_TABLES"){
				        $scope.showErrorModal("მოცემული ჩანაწერის წაშლა შეუძლებელია რადგან ის ფიქსირდება სხვა ცხრილშიც.")
                    }
					return;
				}
				$scope.showSuccessAlert("Success", true);
				$scope.AmfTable.reloadData(true);
			});
        };

        $scope.loadCitiesList = function(){
            $http.get($scope.citiesListURL).success(function (response) {
                if(!response.success){
                    return;
                }
                $scope.cityList = response.results;
            })
        };

        $scope.showUserTags = function(userId){
            if(userId == null){ return; }
            // firing an event
            $rootScope.$emit('loadUserTags', {user_id:userId});
            $("#showUserTags").modal('show');
        };

        $scope.showUserRating = function(userId){
            if(userId == null){ return; }
            // firing an event
            $rootScope.$emit('loadUserRating', {user_id:userId});
            $("#showUserRating").modal('show');
        };

        $scope.$on('upload-finished', function (event, args) {
            if(args.data == "") { $scope.object.imgUrl = null; }
            if (args.data && args.data.length > 0) {
                $scope.object.imgUrl = args.data[0];
            }
        });

        $scope.timeToDateShort = function (time) {
            return new Date(time).toLocaleDateString('ka-GE', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit'
            }).replace(/\./g, '/');
        }
    }]);