(function () {
    'use strict';
    angular
        .module('App')
        .run(runBlock)
        .config(config);

    runBlock.$inject = ['$rootScope', '$state', '$stateParams', '$location', '$http'];

    function runBlock($rootScope, $state, $stateParams, $location, $cookieStore, $http) {
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            //LocationChangeListener
        });
    }

    config.$inject = ['$stateProvider', '$urlRouterProvider', 'MODULE_CONFIG'];
    function config($stateProvider, $urlRouterProvider, MODULE_CONFIG) {

        $urlRouterProvider.otherwise('/category');

        $stateProvider
            .state('category', {
                url: '/category',
				templateUrl:'category/layout',
                controller: 'CategoriesController',
                resolve: load('resources/security/ng/controllers/CategoriesController.js')
            })
            .state('cities', {
                url: '/cities',
                templateUrl:'cities/layout',
                controller: 'CitiesController',
                resolve: load('resources/security/ng/controllers/CitiesController.js')
            })
            .state('user', {
                url: '/user',
                templateUrl:'user/layout',
                controller: 'UserController',
                resolve: load([
                    'resources/security/ng/controllers/UserController.js',
                    'resources/security/ng/controllers/UserRatingController.js',
                    'resources/security/ng/controllers/UserTagsController.js'
                ])
            })
            .state('training', {
                url: '/training',
                templateUrl:'training/adminLayout',
                controller: 'TrainingController',
                resolve: load([
                    'resources/security/ng/controllers/TrainingController.js',
                    'resources/security/ng/controllers/UserSearchController.js'
                ])
            })
            .state('tags', {
                url: '/tags',
                templateUrl:'tags/layout',
                controller: 'TagsController',
                resolve: load('resources/security/ng/controllers/TagsController.js')
            });

        function load(srcs, callback) {
            console.log("Loading:"+srcs);
            return {
                deps: ['$ocLazyLoad', '$q',
                    function ($ocLazyLoad, $q) {
                        var deferred = $q.defer();
                        var promise = false;
                        srcs = angular.isArray(srcs) ? srcs : srcs.split(/\s+/);
                        if (!promise) {
                            promise = deferred.promise;
                        }
                        angular.forEach(srcs, function (src) {
                            promise = promise.then(function () {
                                angular.forEach(MODULE_CONFIG, function (module) {
                                    if (module.name == src) {
                                        src = module.module ? module.name : module.files;
                                    }
                                });
                                return $ocLazyLoad.load(src);
                            });
                        });
                        deferred.resolve();
                        return callback ? promise.then(function () {
                            return callback();
                        }) : promise;
                    }]
            }
        }

        function getParams(name) {
            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                results = regex.exec(location.search);
            return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }
    }


})();
