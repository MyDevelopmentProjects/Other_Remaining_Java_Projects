angular.module('App').service('ModalManager', function ($rootScope, $sce) {

    this.enableModals = function ($scope) {
        $scope.showSuccessAlert = this.showSuccessAlert;
        $scope.showErrorModal = this.showErrorModal;
    };

    this.showSuccessAlert = function (title, success) {
        $.notify(!title ? "" : title, success ? "success" : "error");
    };

    this.showErrorModal = function (title, success) {
        $.notify(title, success ? "success" : "error");
    };

});