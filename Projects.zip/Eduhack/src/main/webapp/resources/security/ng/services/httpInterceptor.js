angular.module('App').factory('httpInterceptor', function ($q, $rootScope, ModalManager) {
        var numLoadings = 0;
        return {
            request: function (config) {
                numLoadings++;
                if (config.showLoader != 0)
                    $('.loader').fadeIn();
                return config || $q.when(config);
            },
            response: function (response) {
                if ((--numLoadings) === 0) {
                    setTimeout(function(){
                        $('.loader').fadeOut();
                    },1000)
                }
                return response || $q.when(response);
            },
            responseError: function (response) {
                if (!(--numLoadings)) {
                }
                //console.error(response.config.url, response.data, response.status)
                setTimeout(function(){
                    $('.loader').fadeOut();
                },1000)
                return $q.reject(response);
            }
        };
    })
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push('httpInterceptor');
    });