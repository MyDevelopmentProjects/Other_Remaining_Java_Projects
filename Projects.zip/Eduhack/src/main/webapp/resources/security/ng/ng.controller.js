angular.module('App.controllers', []).controller('AppCtrl', ['$scope', function ($scope) {
	console.log("Loading Controller Listener..");
}]);
	
