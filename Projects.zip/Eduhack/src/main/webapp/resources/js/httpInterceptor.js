angular.module('eduhack').factory('httpInterceptor', function ($q, $rootScope) {
        var numLoadings = 0;
        return {
            request: function (config) {
                numLoadings++;
                if (config.showLoader != 0) $rootScope.$broadcast("loader_show");
                return config || $q.when(config);
            },
            response: function (response) {
                //Show any message here

                if ((--numLoadings) === 0) {
                    $rootScope.$broadcast("loader_hide");
                }
                return response || $q.when(response);
            },
            responseError: function (response) {
                if (!(--numLoadings)) {
                    $rootScope.$broadcast("loader_hide");
                }
                //Show any message here
                return $q.reject(response);
            }
        };
    })
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push('httpInterceptor');
    });