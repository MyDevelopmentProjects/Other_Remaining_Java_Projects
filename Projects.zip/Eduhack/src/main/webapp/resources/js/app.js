var app = angular.module('eduhack', ['ngRoute', 'angularUtils.directives.dirPagination', 'ngMap', 'ui.bootstrap', 'ui.mask', 'angular-jquery-locationpicker']);

app.config(function ($routeProvider, $httpProvider) {

    $httpProvider.defaults.headers.put['Content-Type'] = 'application/json';
    $httpProvider.defaults.headers.post['Content-Type'] = 'application/json';

    $routeProvider

        .when('/', {
            redirectTo: '/index'
        })

        .when('/index', {
            url: '/index',
            templateUrl: 'index',
            controller: 'MainController'
        })

        .when('/about', {
            templateUrl: 'about',
            controller: 'contentController'
        })

        .when('/faq', {
            templateUrl: 'faq',
            controller: 'contentController'
        })

        .when('/profile', {
            templateUrl: 'profile',
            controller: 'profileController'
        })

        .when('/profile/edit', {
            templateUrl: 'profile/edit',
            controller: 'profileEditController'
        })

        .when('/profile/add-training', {
            templateUrl: 'profile/addTraining',
            controller: 'trainingController'
        })

        .when('/rules', {
            templateUrl: 'rules',
            controller: 'contentController'
        })

        // Trainers
        .when('/trainersAndOrganisations/popularTrainers', {
            templateUrl: 'pages/trainers.html',
            controller: 'trainersController'
        })

        .when('/trainers', {
            templateUrl: 'trainersAndOrganisations/trainerLayout',
            controller: 'trainersController'
        })

        .when('/trainers/:trainer', {
            templateUrl: 'trainersAndOrganisations/trainerInner',
            controller: 'trainersController'
        })

        .when('/organizations', {
            templateUrl: 'trainersAndOrganisations/organisationLayout',
            controller: 'organizationController'
        })

        .when('/organizations/:organisation', {
            templateUrl: 'trainersAndOrganisations/organisationInner',
            controller: 'organizationController'
        })

        .when('/register', {
            templateUrl: 'register/choosePage',
            controller: 'registerController'
        })

        .when('/register/trainer', {
            templateUrl: 'register/trainer',
            controller: 'registerController'
        })

        .when('/register/organisation', {
            templateUrl: 'register/organisation',
            controller: 'registerController'
        })

        .when('/trainings', {
            templateUrl: 'training/layout',
            controller: 'trainingController'
        })

        .when('/trainings/filter/:category', {
            templateUrl: 'training/layout',
            controller: 'trainingController'
        })

        .when('/trainings/:training', {
            templateUrl: 'training/innerLayout',
            controller: 'trainingController'
        })

        .when('/error/404', {
            templateUrl: '/error/404',
            controller: 'MainController'
        })

        .otherwise({
            redirectTo: '/error/404'
        });
});
app.controller('HeaderCtrl', function ($scope, $location) {

    $scope.isActive = function (viewLocation) {
        return viewLocation != $location.path();
    };

    $scope.loginPopup = function () {
        var loginPopup = angular.element(document.getElementsByClassName('sign-in'));
        loginPopup.addClass('expended');
    };
});
app.controller('MainController', function ($scope, $http) {
    $http({
        method: 'GET',
        url: '/trainersAndOrganisations/popularTrainers'
    }).success(function (data) {
        $scope.popularTrainers = data.results;
    }).error(function () {

    });

    $http({
        method: 'GET',
        url: '/trainersAndOrganisations/popularCompany'
    }).success(function (data) {
        $scope.popularCompany = data.results;
    }).error(function () {

    });

    $http.get("/category/list?pageSize=4")
        .success(function (data) {
            $scope.category_list = data.results;
        });

    $http.get("/trainersAndOrganisations/statistics")
        .success(function (data) {
            $scope.statistics = data;
        });

});
app.controller('contentController', function ($scope) {
    $('header').removeClass('header--inner');
    $("html, body").animate({scrollTop: 0}, "slow");
});
app.controller('loginController', function ($scope, $http) {
    $scope.closeLogin = function () {
        var loginPopup = angular.element(document.getElementsByClassName('sign-in'));
        loginPopup.removeClass('expended');
    };

    $scope.login = function () {
        $.ajax({
            url: "/authenticate",
            type: "POST",
            beforeSend: function (request) {
                request.setRequestHeader("X-Login-Ajax-call", true);
            },
            contentType: "application/x-www-form-urlencoded", // send as JSON
            data: $("#loginForm").serialize(),

            complete: function () {
                //called when complete
            },

            success: function (data) {
                if (!data.success) {
                    swal('არასწორი მომხმარებელი & პაროლი, ან თქვენი ექაუნთი ჯერ არ არის გააქტიურებული!');
                    return;
                } else {
                    var user = data.results[0].userName;
                    swal(user + ', თქვენ წარმატებით გაიარეთ ავტორიზაცია');
                    setTimeout(function () {
                        window.location.href = "/"
                    }, 1300)
                }
            },

            error: function () {
                swal('არასწორი მომხმარებელი & პაროლი, ან თქვენი ექაუნთი ჯერ არ არის გააქტიურებული!');
            }
        });

    }
});
app.controller('mainPageController', function () {
    $('header').removeClass('header--inner');
    $("html, body").animate({scrollTop: 0}, "slow");
});
app.controller('organizationController', ['$scope', '$http', '$routeParams', 'GridManager', function ($scope, $http, $routeParams, GridManager) {
    angular.extend($scope, {
        url: '/search/user?isTrainer=false&sortField=id'
    });

    GridManager.givePowerTo($scope);
    $scope.AmfTable.pageLimit = 6;
    $scope.AmfTable.openPage(0);

    $http({
        method: 'GET',
        url: '/trainersAndOrganisations/popularCompany'
    }).success(function (data) {
        $scope.popularCompany = data.results;
    }).error(function () {
        alert("error");
    });

    if ($routeParams.organisation != undefined) {
        $http({
            method: 'GET',
            url: '/trainersAndOrganisations/organisation/' + parseInt($routeParams.organisation)
        }).success(function (data) {
            $scope.org_data = data;
        }).error(function () {
            $scope.org_data = {};
        });
    }
    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };

    $scope.countTags = function(type){
        var value = 0;
        for (var i in $scope.org_data.tags){
            if($scope.org_data.tags[i].tag.type == type){
                value++;
            }
        }
        return value;
    };

}]);
app.controller('registerController', function ($scope, $http) {
    var phoneReg = new RegExp('^[0-9]+$');
    var mailReg = /\S+@\S+\.\S+/;
    $('[data-toggle="datepicker"]').datepicker({
        format: 'yyyy-mm-dd'
    });

    // Register Function
    $scope.register = function (type) {
        if (type == 'trainer') {
            $scope.object.trainer = true;

            if ($scope.object.password !== $scope.object.repeatpassword) {
                swal('პაროლები ერთმანეთს არ ემთხვევა');
                return false;
            } else if (!$scope.object.mNumber.match(phoneReg)) {
                swal('გთხოვთ შეიყვანოთ სწორი მობილურის ნომერი');
                return false;
            } else if (!$scope.object.email.match(mailReg)) {
                swal('გთხოვთ შეიყვანოთ სწორი მეილი');
            } else if (!$('#rulesCheck').is(':checked')) {
                swal('დაეთანხმეთ პირობებს');
            } else {
                delete $scope.object.repeatpassword;
                $http.post('register/create', $scope.object).success(function (data) {
                    if (!data.success) {
                        if (data.errorMessage && data.errorMessage == "USER_EXISTS") {
                            swal('მომხმარებელი მითითებული სახელით უკვე არსებობს.');
                        } else {
                            swal('სამწუხაროდ რეგისტრაცია ვერ დასრულდა წარმატებით. დარწმუნდით თქვენი ინფოს სისწორეში');
                        }
                    } else {
                        swal('თქვენ წარმატებით გაიარეთ რეგისტრაცია');
                        setTimeout(function () {
                            window.location.href = "/"
                        }, 1300)
                    }
                });
            }
        } else {
            $scope.object.trainer = false;

            if ($scope.object.password !== $scope.object.repeatpassword) {
                swal('პაროლები ერთმანეთს არ ემთხვევა');
                return false;
            } else if (!$scope.object.mNumber.match(phoneReg)) {
                swal('გთხოვთ შეიყვანოთ სწორი მობილურის ნომერი');
                return false;
            } else if (!$scope.object.email.match(mailReg)) {
                swal('გთხოვთ შეიყვანოთ სწორი მეილი');
            } else if (!$('#rulesCheck').is(':checked')) {
                swal('დაეთანხმეთ პირობებს');
            } else {
                delete $scope.object.repeatpassword;
                $http.post('register/create', $scope.object).success(function (data) {
                    if (!data.success) {
                        swal('სამწუხაროდ რეგისტრაცია ვერ დასრულდა წარმატებით. დარწმუნდით თქვენი ინფოს სისწორეში');
                    } else {
                        swal('თვენ წარმატებით გაიარეთ რეგისტრაცია');
                        setTimeout(function () {
                            window.location.href = "/"
                        }, 1300)
                    }
                });
            }
        }
    };

    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };

});
app.controller('trainersController', ['$scope', '$http', '$routeParams', 'GridManager', function ($scope, $http, $routeParams, GridManager) {
    angular.extend($scope, {
        url: '/search/user?isTrainer=true&sortField=id'
    });

    GridManager.givePowerTo($scope);
    $scope.AmfTable.pageLimit = 9;
    $scope.AmfTable.openPage(0);

    $http({
        method: 'GET',
        url: '/trainersAndOrganisations/popularTrainers'
    }).success(function (data) {
        $scope.popularTrainers = data.results;
        $scope.valid = true;
        if ($scope.popularTrainers.imgUrl == null) {
            $scope.valid = false;
        }
        return $scope.popularTrainers;
    }).error(function () {
        alert("error");
    });

    if ($routeParams.trainer != undefined) {
        $http({
            method: 'GET',
            url: '/trainersAndOrganisations/trainer/' + parseInt($routeParams.trainer)
        }).success(function (data) {
            $scope.user_data = data;
        }).error(function () {
            $scope.user_data = {};
        });
    }

    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };
}]);
app.controller('trainingController', ['$scope', '$http', '$routeParams', 'GridManager', function ($scope, $http, $routeParams, GridManager) {

    $('[data-toggle="datepicker"]').datepicker({
        format: 'yyyy-mm-dd'
    });

    $scope.locationpickerOptions = {
        location: {
            latitude: 41.732438,
            longitude: 44.7688134
        },
        inputBinding: {
            locationNameInput: $('#addres-name')
        },
        radius: 300,
        enableAutocomplete: true
    };

    angular.extend($scope, {
        url: '/training/public/list'
    });

    if ($routeParams.category != undefined) {
        $scope.url = '/training/public/list?categoryId=' + parseInt($routeParams.category);
    }

    if ($routeParams.training != undefined) {
        $http({
            method: 'GET',
            url: '/training/' + parseInt($routeParams.training)
        }).success(function (data) {
            $scope.training_data = data;
        }).error(function () {
            $scope.training_data = {};
        });
    }

    $scope.training = {};
    $scope.searchOrgs = [];
    $scope.orgs = [];
    $scope.searchTrainers = [];
    $scope.trainers = [];
    $scope.trainerTitle = "";
    $scope.orgTitle = "";

    GridManager.givePowerTo($scope);
    $scope.AmfTable.pageLimit = 9;
    $scope.AmfTable.openPage(0);

    $http.get("/cities/list?pageSize=-255")
        .success(function (data) {
            $scope.city_list = data.results;
        });

    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };

    $scope.loadCategoryList = function () {
        $http.get("/category/list?pageSize=-255")
            .success(function (data) {
                $scope.category_list = data.results;
            });
    };

    $scope.uploadImage = function () {
        var length = document.getElementById("file").files.length;
        if (length > 0) {
            var formData = new FormData();
            formData.append('file', document.getElementById("file").files[0]);
            formData.append('type', "TRAINING");
            $http({
                url: 'upload/file',
                method: "POST",
                data: formData,
                headers: {'Content-Type': undefined}
            }).success(function (response) {
                $scope.updateImagePath(response)
            });
        }
    };

    $scope.saveTrainingDetails = function () {

        var numArr = [];
        for (var i = 0; i < $scope.orgs.length; i++)
            numArr.push($scope.orgs[i].id)
        for (var i = 0; i < $scope.trainers.length; i++)
            numArr.push($scope.trainers[i].id)

        $http.post("training/updateObjects?ids=" + numArr + "&trainingId=" + $scope.training.id)
            .success(function (data) {
                if (data.success) {
                    swal('ოპერაცია შესრულდა წარმატებით')
                    window.location.href = "#/index"
                } else {
                    delete $scope.training.id;
                    swal('შენახვა ვერ მოხერხდა. სცადეთ თავიდან')
                }
            });
    };

    $scope.updateImagePath = function (img) {
        if (img && img.length > 0) {
            $scope.training.imgUrl = img[0];
            $http.post("training/update", $scope.training)
                .success(function (data) {
                    if (!data.success) {
                        swal('შენახვა ვერ მოხერხდა. სცადეთ თავიდან')
                    }
                });
        }
    };

    $scope.saveTraining = function () {

        if ($scope.orgs.length == 0 || $scope.trainers.length == 0) {
            swal('აირჩიეთ მინიმუმ 1 ტრენერი და 1 ორგანიზაცია!');
            return
        }

        $http.post("training/public/save", $scope.training)
            .success(function (data) {
                if (data > 0) {
                    $scope.training.id = data;
                    $scope.uploadImage();
                    $scope.saveTrainingDetails();
                } else {
                    delete $scope.training.id;
                    swal('შენახვა ვერ მოხერხდა. სცადეთ თავიდან')
                }
            });
    };

    $scope.addOrg = function (person) {
        if (!person)return;
        if ($scope.orgs.length == 20) {
            swal('20-ზე მეტი ორგანიზაციის დამატება შეუძლებელია')
            return;
        }

        var newPerson = angular.copy(person);

        var exists = false;
        angular.forEach($scope.orgs, function (object) {
            if (object && object.id == newPerson.id) {
                exists = true;
            }
        });
        if (!exists)
            $scope.orgs.push(newPerson);
    };

    $scope.removeOrg = function (index) {
        $scope.orgs.splice(index, 1);
    };

    $scope.addTrainer = function (person) {
        if (!person)return;
        if ($scope.trainers.length == 20) {
            swal('20-ზე მეტი ტრენერის დამატება შეუძლებელია')
            return;
        }

        var newPerson = angular.copy(person);

        var exists = false;
        angular.forEach($scope.trainers, function (object) {
            if (object && object.id == newPerson.id) {
                exists = true;
            }
        });
        if (!exists)
            $scope.trainers.push(newPerson);
    };

    $scope.removeTrainer = function (index) {
        $scope.trainers.splice(index, 1);
    };

    $scope.close = function () {
        $('.orgPopup').fadeOut()
    };

    $scope.searchForTrainers = function () {
        $http.get("search/user?searchExpression=" + $scope.trainerTitle + "&isTrainer=true")
            .success(function (data) {
                if (data.success) {
                    $scope.searchTrainers = data.results;
                } else {
                    $scope.searchTrainers = [];
                }
            });
    };

    $scope.searchForOrgs = function () {
        $http.get("search/user?name=" + $scope.orgTitle + "&isTrainer=false")
            .success(function (data) {
                if (data.success) {
                    $('.orgPopup').show()
                    $scope.searchOrgs = data.results;
                } else {
                    $scope.searchOrgs = [];
                }
            });
    };

    $scope.mapSearchPopup = function () {
        var map = angular.element(document.getElementsByClassName('map-modal'));
        map.addClass('expended');
    };

    $scope.closeMapSearchPopup = function () {
        var loginPopup = angular.element(document.getElementsByClassName('map-modal'));
        loginPopup.removeClass('expended');
    }
}]);
app.controller('profileController', ['$scope', '$http', '$routeParams', function ($scope, $http, $routeParams) {

    $('[data-toggle="datepicker"]').datepicker({
        format: 'yyyy-mm-dd'
    });

    $http.get("user/self")
        .success(function (data) {
            if (data.success) {
                $scope.auth_user = data.results[0];
            }
        });

    $http.get("/user/tags")
        .success(function (data) {
            $scope.user_tags = data.results;
        });

    $http.get("/user/rating")
        .success(function (data) {
            $scope.user_rating = data.results;
        });

    $http.get("/tags/public/list")
        .success(function (data) {
            $scope.tags_list = data.results
        });

    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };

    $scope.loadCategoryList = function () {
        $http.get("/category/list?pageSize=-255")
            .success(function (data) {
                $scope.category_list = data.results;
            });
    };

    $scope.$on('upload-finished', function (event, args) {
        if (args.data && args.data.length > 0) {
            $scope.saveUploadedImage(args.data[0]);
        }
    });

    $scope.updateUserDescription = function () {
        var value = $("#description").val();
        $http.post('/user/update/description', value)
            .success(function (response) {
                if (!response.success) {
                    swal('ვერმოხერხდა ტექსტის განახლება.');
                } else {
                    setTimeout(function () {
                        $("#old_description").text(value);
                    }, 1000)
                }
                $scope.edit = false;
            })
    };

    $scope.saveUploadedImage = function (imgURL) {
        $http.post('/user/upload', imgURL).success(function (response) {
            if (!response.success) {
                swal('ვერმოხერხდა სურათის ატვირთვა.');
            } else {
                $("#user_image").attr('src', '/uploads/users/' + imgURL.replace('_thumb', ''));
                $("#user_image_thumb").attr('src', '/uploads/users/' + imgURL);
            }
        });
    };

    $scope.putTag = function (event, tagId) {
        $http.post("/user/tag/put", tagId)
            .success(function (data) {
                if (!data.success) {
                    swal('დაფიქსირდა შეცდომა. სცადეთ მოგვიანებით');
                } else {
                    $(event.target).toggleClass('active');
                }
            })
    };

    $scope.isExists = function (id) {
        for (var i in $scope.user_tags) {
            if ($scope.user_tags[i].tag.id == id) {
                return true;
            }
        }
        return false;
    };

    $scope.countTags = function(type){
        var value = 0;
        for (var i in $scope.tags_list){
            if($scope.tags_list[i].type == type){
                value++;
            }
        }
        return value;
    };
}]);
app.controller('profileEditController', ['$scope', '$http', '$routeParams', function ($scope, $http, $routeParams) {

    var phoneReg = new RegExp('^[0-9]+$');
    var mailReg = /\S+@\S+\.\S+/;

    $('[data-toggle="datepicker"]').datepicker({
        format: 'yyyy-mm-dd'
    });

    $scope.genderOptions = [
        {id: 1, name: "მამრობითი", value: true},
        {id: 2, name: "მდედრობითი", value: false}
    ];

    $http.get("user/self")
        .success(function (data) {
            if (data.success) {
                $scope.user_object = data.results[0];

                if ($scope.user_object.dob != null) {
                    $scope.user_object.dob = utils.timeToDateShort($scope.user_object.dob);
                }
            }
        });

    $scope.loadCitiesList = function () {
        $http.get("/cities/list?pageSize=-255")
            .success(function (data) {
                $scope.city_list = data.results;
            });
    };

    $scope.updateUser = function () {
        if ($scope.user_object.password !== $scope.user_object.repeat_password) {
            swal('პაროლები ერთმანეთს არ ემთხვევა');
        } else if (!$scope.user_object.mNumber.match(phoneReg)) {
            swal('გთხოვთ შეიყვანოთ სწორი მობილურის ნომერი');
        } else if (!$scope.user_object.email.match(mailReg)) {
            swal('გთხოვთ შეიყვანოთ სწორი მეილი');
        } else {
            delete $scope.user_object.repeat_password;
            $http.post("/user/editUserData", $scope.user_object)
                .success(function (data) {
                    if (data.success) {
                        setTimeout(function () {
                            window.location.href = "/#/profile";
                            swal('ინფორმაცია წარმათებით განახლდა.');
                        }, 200)
                    } else {
                        if(data.errorMessage && data.errorMessage == "unknown") {
                            swal('დაფიქსირდა შეცდომა სცადეთ მოგვიანებით.');
                        } else {
                            swal(data.errorMessage);
                        }
                    }
                });
        }

    };

}]);
app.directive('convertToNumber', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, ngModel) {
            ngModel.$parsers.push(function (val) {
                return val != null ? parseInt(val, 10) : null;
            });
            ngModel.$formatters.push(function (val) {
                return val != null ? '' + val : null;
            });
        }
    };
});
app.directive('preLoader', function () {
    return function (scope) {
        scope.$on('$viewContentLoaded', function () {
            setTimeout(function () {
                $('.preloader').fadeOut('fast');
            }, 1000);
        });
    };
});
app.directive("compareTo", function () {
    return {
        require: "ngModel",
        scope: {
            otherModelValue: "=compareTo"
        },
        link: function (scope, element, attributes, ngModel) {

            ngModel.$validators.compareTo = function (modelValue) {
                return modelValue == scope.otherModelValue;
            };

            scope.$watch("otherModelValue", function () {
                ngModel.$validate();
            });
        }
    };
});
app.directive('appUpload', function ($rootScope, upload) {
    return {
        restrict: 'A',
        scope: true,
        link: function (scope, element, attr) {
            element.bind('change', function () {
                var formData = new FormData();
                for (var file in element[0].files) {
                    formData.append('file', element[0].files[file]);
                }
                var type = $(element).data('type');
                formData.append('type', type);
                upload('upload/file', formData, function (callback) {
                    $rootScope.$broadcast('upload-finished', {data: callback});
                });
            });
        }
    };
});
app.directive('textMaxlength', ['$compile', function($compile) {
    return {
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, elem, attrs, ctrl) {
            attrs.$set("ngTrim", "false");
            var maxlength = parseInt(attrs.textMaxlength, 10);
            ctrl.$parsers.push(function (value) {
                if (value.length > maxlength)
                {
                    value = value.substr(0, maxlength);
                    ctrl.$setViewValue(value);
                    ctrl.$render();
                }
                return value;
            });
        }
    };
}]);
app.factory('upload', function ($http) {
    return function (file, data, callback) {
        $http({
            url: file,
            method: "POST",
            data: data,
            headers: {'Content-Type': undefined}
        }).success(function (response) {
            callback(response);
        });
    };
});
app.filter('monthName', [function () {
    return function (monthNumber) {
        var monthNames = ['იანვარი', 'თებერვალი', 'მარტი', 'აპრილი', 'მაისი', 'ივნისი',
            'ივლისი', 'აგვისტო', 'სექტემბერი', 'ოქტომბერი', 'ნოემბერი', 'დეკემბერი'];
        return monthNames[monthNumber - 1];
    }
}]);

var utils = {
    timeToDateShort: function (time) {
        return new Date(time).toLocaleDateString('ka-GE', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit'
        }).replace(/\./g, '/');
    },
    compare: function (object, array) {
        for (var i in array) {
            if (object.id == array[i].id) {
                array[i].active = true;
            } else {
                array[i].active = false;
            }
        }
        return false;
    }
};